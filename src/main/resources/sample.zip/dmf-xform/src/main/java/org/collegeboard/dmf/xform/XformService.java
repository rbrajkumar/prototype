package org.collegeboard.dmf.xform;

import com.jayway.jsonpath.DocumentContext;

public interface XformService
{
    public Object transform(XformRequest xformRequest, DocumentContext metadata, String jsonMessage);
}
