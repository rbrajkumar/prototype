package org.collegeboard.dmf.xform.essayscore;

import java.util.List;

public class EssayScore
{
    private String bucketName;
    private String fileName;
    private int recordNo;
    private int totalRecords;
    private String uin;
    private String actionIndicator;
    private String scoreHoldIndicator;
    private String scoreHoldType;
    private String regNumber;
    private String assessment;
    private String adminYear;
    private String adminMonth;
    private String adminDay;
    private String systemFormCode;
    private String ssdFlag;
    private String ssdType;
    private String scoreKeyVersion;
    private String asScanProcessedTimestamp;
    private String naqMetadataMap;
    private String numberOfASScanMetadata;
    private String numberOfNonASQuestions;
    private String numberOfSections;
    private int numberOfScoreTiers;
    private List<ScoreTier> scoreTiers;

    public String getBucketName()
    {
        return bucketName;
    }
    public void setBucketName(String bucketName)
    {
        this.bucketName = bucketName;
    }    
    public String getFileName()
    {
        return fileName;
    }
    public void setFileName(String fileName)
    {
        this.fileName = fileName;
    }

    public int getRecordNo()
    {
        return recordNo;
    }

    public void setRecordNo(int recordNo)
    {
        this.recordNo = recordNo;
    }

    public int getTotalRecords()
    {
        return totalRecords;
    }

    public void setTotalRecords(int totalRecords)
    {
        this.totalRecords = totalRecords;
    }
    public String getUin()
    {
        return uin;
    }
    public void setUin(String uin)
    {
        this.uin = uin;
    }
    public String getActionIndicator()
    {
        return actionIndicator;
    }
    public void setActionIndicator(String actionIndicator)
    {
        this.actionIndicator = actionIndicator;
    }
    public String getScoreHoldIndicator()
    {
        return scoreHoldIndicator;
    }
    public void setScoreHoldIndicator(String scoreHoldIndicator)
    {
        this.scoreHoldIndicator = scoreHoldIndicator;
    }
    public String getScoreHoldType()
    {
        return scoreHoldType;
    }
    public void setScoreHoldType(String scoreHoldType)
    {
        this.scoreHoldType = scoreHoldType;
    }
    public String getRegNumber()
    {
        return regNumber;
    }
    public void setRegNumber(String regNumber)
    {
        this.regNumber = regNumber;
    }
    public String getAssessment()
    {
        return assessment;
    }
    public void setAssessment(String assessment)
    {
        this.assessment = assessment;
    }
    public String getAdminYear()
    {
        return adminYear;
    }
    public void setAdminYear(String adminYear)
    {
        this.adminYear = adminYear;
    }
    public String getAdminMonth()
    {
        return adminMonth;
    }
    public void setAdminMonth(String adminMonth)
    {
        this.adminMonth = adminMonth;
    }
    public String getAdminDay()
    {
        return adminDay;
    }
    public void setAdminDay(String adminDay)
    {
        this.adminDay = adminDay;
    }
    public String getSystemFormCode()
    {
        return systemFormCode;
    }
    public void setSystemFormCode(String systemFormCode)
    {
        this.systemFormCode = systemFormCode;
    }
    public String getSsdFlag()
    {
        return ssdFlag;
    }
    public void setSsdFlag(String ssdFlag)
    {
        this.ssdFlag = ssdFlag;
    }
    public String getSsdType()
    {
        return ssdType;
    }
    public void setSsdType(String ssdType)
    {
        this.ssdType = ssdType;
    }
    public String getScoreKeyVersion()
    {
        return scoreKeyVersion;
    }
    public void setScoreKeyVersion(String scoreKeyVersion)
    {
        this.scoreKeyVersion = scoreKeyVersion;
    }
    public String getAsScanProcessedTimestamp()
    {
        return asScanProcessedTimestamp;
    }
    public void setAsScanProcessedTimestamp(String asScanProcessedTimestamp)
    {
        this.asScanProcessedTimestamp = asScanProcessedTimestamp;
    }
    public String getNaqMetadataMap()
    {
        return naqMetadataMap;
    }
    public void setNaqMetadataMap(String naqMetadataMap)
    {
        this.naqMetadataMap = naqMetadataMap;
    }
    public String getNumberOfASScanMetadata()
    {
        return numberOfASScanMetadata;
    }
    public void setNumberOfASScanMetadata(String numberOfASScanMetadata)
    {
        this.numberOfASScanMetadata = numberOfASScanMetadata;
    }
    public String getNumberOfNonASQuestions()
    {
        return numberOfNonASQuestions;
    }
    public void setNumberOfNonASQuestions(String numberOfNonASQuestions)
    {
        this.numberOfNonASQuestions = numberOfNonASQuestions;
    }
    public String getNumberOfSections()
    {
        return numberOfSections;
    }
    public void setNumberOfSections(String numberOfSections)
    {
        this.numberOfSections = numberOfSections;
    }

    public int getNumberOfScoreTiers()
    {
        return numberOfScoreTiers;
    }

    public void setNumberOfScoreTiers(int numberOfScoreTiers)
    {
        this.numberOfScoreTiers = numberOfScoreTiers;
    }
    public List<ScoreTier> getScoreTiers()
    {
        return scoreTiers;
    }
    public void setScoreTiers(List<ScoreTier> scoreTiers)
    {
        this.scoreTiers = scoreTiers;
    }

}
