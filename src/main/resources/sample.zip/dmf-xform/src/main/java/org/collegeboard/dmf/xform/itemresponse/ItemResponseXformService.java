package org.collegeboard.dmf.xform.itemresponse;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.collegeboard.dmf.common.utils.DMFConstants;
import org.collegeboard.dmf.common.utils.DMFHttpClient;
import org.collegeboard.dmf.common.utils.DMFHttpResponse;
import org.collegeboard.dmf.common.utils.DMFUtils;
import org.collegeboard.dmf.xform.XformRequest;
import org.collegeboard.dmf.xform.XformService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.Criteria;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.Filter;
import com.jayway.jsonpath.JsonPath;

public class ItemResponseXformService implements XformService
{

    private static final Logger LOGGER = LoggerFactory.getLogger(ItemResponseXformService.class);

    private static String bsAssessInfoURL;
    private static String bsAssessInfoURLMediaType;

    private static String bsAsmtRegURL;
    private static String bsAsmtRegMediaType;

    private ItemResponseXformDynmaoDAO itemResponseDAO;

    public ItemResponseXformService()
    {
        if (bsAssessInfoURL == null)
        {
            //TODO get these from metadata
            bsAssessInfoURL = System.getenv("BSASSESINFO_SERVICE_URL");
            bsAssessInfoURLMediaType = "application/vnd.collegeboard.org.bsassessinfo-v1.0+json";
        }

        if (bsAsmtRegURL == null)
        {
            //TODO get these from metadata
            bsAsmtRegURL = System.getenv("BSASMTREG_SERVICE_URL");
            bsAsmtRegMediaType = "application/vnd.collegeboard.org.bsasmtreg-v1.0+json";
        }

        itemResponseDAO = new ItemResponseXformDynmaoDAO();
    }

    @Override
    public Object transform(XformRequest xformRequest, DocumentContext metadata, String jsonMessage)
    {
        DocumentContext inputJsonDoc = null;
        try
        {
            inputJsonDoc = JsonPath.parse(jsonMessage, DMFUtils.getJsonParserConfiguration());

            loadBSServicesData(inputJsonDoc);
            String systemFormId = inputJsonDoc.read(ItemResponseConstants.FORM_ID_JPATH, String.class);
            inputJsonDoc.put("$", ItemResponseConstants.SYSTEM_FORM_ID_KEY, systemFormId);
            updateSourceFormCode(metadata, inputJsonDoc, systemFormId);
            updateItemResponseDetails(inputJsonDoc, systemFormId);
            setQcFlag(inputJsonDoc);
        } catch (Exception ex)
        {
            throw new RuntimeException(ex);
        }
        return inputJsonDoc.jsonString();
    }
    
    private void setQcFlag(DocumentContext inputJsonDoc) {
    	inputJsonDoc.put("$", ItemResponseConstants.QC_FLAG_KEY, getQcFlag(inputJsonDoc));
    }
    
    private String getQcFlag(DocumentContext inputJsonDoc) {
    	// Gather all required values
    	Integer eventId = (Integer) getTesteeAttributeValue(inputJsonDoc,
                ItemResponseConstants.TESTEEATTR_NAME_EVENT_ID);    	    	    	
    	Integer asmtId = inputJsonDoc.read(ItemResponseConstants.ASMT_ID, Integer.class);
    	String airkey= inputJsonDoc.read(ItemResponseConstants.AIRKEY_JPATH, String.class);
    	
    	//if form level code set
    	if(isFormLevelQCFlagApplied(eventId, airkey, asmtId, inputJsonDoc.read(ItemResponseConstants.SYSTEM_FORM_ID_KEY)))
    	{
    		//return A
    		return ItemResponseConstants.QC_FLAG_A;
    	}
    	//if ed level code set
    	if(isEdLevelQCFlagApplied(eventId, airkey, asmtId, inputJsonDoc.read(ItemResponseConstants.ED_LEVEL_CD)))
    	{
    		//return C
    		return ItemResponseConstants.QC_FLAG_C;
    	}
    	
    	//return N    	    
    	return ItemResponseConstants.QC_FLAG_N;
    }       
    
    private void loadBSServicesData(DocumentContext inputJsonDoc) throws InterruptedException, ExecutionException
    {
        Integer eventId = (Integer) getTesteeAttributeValue(inputJsonDoc,
                ItemResponseConstants.TESTEEATTR_NAME_EVENT_ID);
        String regNumber = (String) getTesteeAttributeValue(inputJsonDoc,
                ItemResponseConstants.TESTEEATTR_NAME_EXTERNAL_ID);

        List<Callable<DMFHttpResponse>> callables = Arrays.asList(() -> {
            LOGGER.info("starting task1");
            String getEventURL = bsAssessInfoURL + "assessments/events/" + eventId;

            DMFHttpClient httpClient = new DMFHttpClient();
            DMFHttpResponse response = httpClient.doGet(getEventURL, bsAssessInfoURLMediaType,
                    DMFConstants.DMF_CLOUD_SOA_PREFIX);

            LOGGER.info("end task1");
            return response;
        }, () -> {
            LOGGER.info("starting task2");
            String registrationsURL = bsAsmtRegURL + "registrations/regnumber/" + regNumber;

            DMFHttpClient httpClient = new DMFHttpClient();
            DMFHttpResponse response = httpClient.doGet(registrationsURL, bsAsmtRegMediaType,
                    DMFConstants.DMF_CLOUD_SOA_PREFIX);

            LOGGER.info("end task2");
            return response;
        });

        ExecutorService executor = Executors.newFixedThreadPool(2);
        List<Future<DMFHttpResponse>> futures = executor.invokeAll(callables);
        executor.shutdown();
        LOGGER.info("processing service responses");
        processBsAssessInfoResponse(futures.get(0).get(), inputJsonDoc);
        processBsAsmtRegResponse(futures.get(1).get(), inputJsonDoc);
    }

    private Object getTesteeAttributeValue(DocumentContext inputJsonDoc, String attributeName)
    {
        Filter regNumberFilter = Filter.filter(Criteria.where(ItemResponseConstants.TESTEEATTR_NAME_KEY).is(
                attributeName));
        List<Object> attributeValues = inputJsonDoc.read(ItemResponseConstants.TESTEEATTRVAL_JPATH, regNumberFilter);
        if (attributeValues.size() == 1)
        {
            return attributeValues.get(0);
        } else
        {
            return null;
        }

    }

    private void processBsAssessInfoResponse(DMFHttpResponse response, DocumentContext inputJsonDoc)
    {
        if (!DMFHttpClient.isSuccess(response.getStatusCode()))
        {
            throw new RuntimeException("Error in service call");
        }

        Configuration configuration = DMFUtils.getJsonParserConfiguration();
        DocumentContext responseDocContext = JsonPath.parse(response.getResponseJson(), configuration);

        String startDate = responseDocContext.read(ItemResponseConstants.START_DATE_JPATH, String.class);

        if (DMFUtils.isEmptyString(startDate) || (startDate != null && startDate.length() != 10))
        {
            throw new RuntimeException(String.format("Invalid startDate:%s", startDate));
        }

        String adminYear = startDate.substring(0, 4);
        String adminMonth = startDate.substring(5, 7);
        String adminDay = startDate.substring(8, 10);

        inputJsonDoc.put("$", ItemResponseConstants.ADMIN_DATE_SRF_KEY, DMFUtils.formatDate(startDate,
                ItemResponseConstants.ADMIN_DATE_SRF_AIR_FORMAT, ItemResponseConstants.ADMIN_DATE_SRF_CB_FORMAT));
        inputJsonDoc.put("$", ItemResponseConstants.ADMIN_YR_KEY, adminYear);
        inputJsonDoc.put("$", ItemResponseConstants.ADMIN_MONTH_KEY, adminMonth);
        inputJsonDoc.put("$", ItemResponseConstants.ADMIN_DAY_KEY, adminDay);

    }

    private void processBsAsmtRegResponse(DMFHttpResponse response, DocumentContext inputJsonDoc)
    {
        if (!DMFHttpClient.isSuccess(response.getStatusCode()))
        {
            throw new RuntimeException("Error in service call");
        }

        Configuration configuration = DMFUtils.getJsonParserConfiguration();
        DocumentContext responseDocContext = JsonPath.parse(response.getResponseJson(), configuration);

        Integer asmtId = responseDocContext.read(ItemResponseConstants.ASMT_RESP_ASMT_ID_JPATH, Integer.class);
        Integer asmtSubType = responseDocContext.read(ItemResponseConstants.ASMT_RESP_ASMT_SUB_TYP_CD_JPATH, Integer.class);
        String aiCode = responseDocContext.read(ItemResponseConstants.ASMT_RESP_AI_CD_JPATH, String.class);
        Integer personId = responseDocContext.read(ItemResponseConstants.ASMT_RESP_PERSON_ID_JPATH, Integer.class);
        String educationLvl = responseDocContext.read(ItemResponseConstants.ASMT_RESP_ED_LEVEL_CD_JPATH, String.class);
        String assessment = null;
        String naqMetadataMap = null;

        if ((asmtId != null && asmtId.intValue() == 99) && (asmtSubType != null && asmtSubType.intValue() == 1))
        {
            assessment = ItemResponseConstants.ASMT_RSAT_ESSAY;
            naqMetadataMap = ItemResponseConstants.NAQ_MTDT_MAP_RSAT_ESSAY;
        } else if ((asmtId != null && asmtId.intValue() == 99) && (asmtSubType != null && asmtSubType.intValue() == 2))
        {
            assessment = ItemResponseConstants.ASMT_DIGI_RSAT;
            naqMetadataMap = ItemResponseConstants.NAQ_MTDT_MAP_DIGI_RSAT;
        } else if ((asmtId != null && asmtId.intValue() == 100) && (asmtSubType != null && asmtSubType.intValue() == 3))
        {
            assessment = ItemResponseConstants.ASMT_DIGI_PSAT_10;
            naqMetadataMap = ItemResponseConstants.NAQ_MTDT_MAP_DIGI_PSAT_10;
        } else if (asmtId != null && asmtId.intValue() == 102)
        {
            assessment = ItemResponseConstants.ASMT_DIGI_PSAT_8_9;
            naqMetadataMap = ItemResponseConstants.NAQ_MTDT_MAP_DIGI_PSAT_8_9;
        } else
        {
            throw new RuntimeException(String.format("Invalid asmtId:%s, asmtSubType:%s", asmtId, asmtSubType));
        }

        inputJsonDoc.put("$", ItemResponseConstants.ASMT_KEY, assessment);
        inputJsonDoc.put("$", ItemResponseConstants.NAQ_MTDT_MAP_KEY, naqMetadataMap);
        inputJsonDoc.put("$", ItemResponseConstants.ATND_AI_CD_KEY, aiCode);
        inputJsonDoc.put("$", ItemResponseConstants.PERSON_ID_KEY, personId);
        inputJsonDoc.put("$", ItemResponseConstants.ASMT_SUB_TYPE_CD, asmtSubType);
        inputJsonDoc.put("$", ItemResponseConstants.ASMT_ID, asmtId);
        inputJsonDoc.put("$", ItemResponseConstants.ED_LEVEL_CD, educationLvl);
    }

    @SuppressWarnings("unchecked")
    private void updateItemResponseDetails(DocumentContext inputJsonDoc, String systemFormId)
    {
        List<?> responses = null;
        String bankKey = null;
        String airKey = null;
        Map<?, ?> mainResponseMap = null;
        Map<?, ?> itemresponseMap = null;
        Map<String, Object> responseMap = null;
        Object userChoice = null;
        Object responseValue = null;


        List<LinkedHashMap<String, ?>> items = inputJsonDoc.read(ItemResponseConstants.ITEM_JPATH);

        if (items == null)
        {
            return;
        }

        for (LinkedHashMap<String, ?> item : items)
        {

            bankKey = String.valueOf(item.get(ItemResponseConstants.ITEM_BANKKEY));
            airKey = String.valueOf(item.get(ItemResponseConstants.ITEM_AIRKEY));
            responses = (List<?>) item.get(ItemResponseConstants.ITEM_MAINRESPONSE);

            mainResponseMap = (LinkedHashMap<?, ?>) responses.get(1);
            itemresponseMap = (LinkedHashMap<?, ?>) mainResponseMap.get(ItemResponseConstants.ITEM_ITEM_RESPONSE);
            responseMap = (LinkedHashMap<String, Object>) itemresponseMap.get(ItemResponseConstants.ITEM_RESPONSE);

            responseValue = responseMap.get(ItemResponseConstants.ITEM_RESPONSE_VALUE);

            if (responseValue == null || 
                  (responseValue instanceof String && DMFUtils.isEmptyString((String) responseValue)))
            {
                continue;
            }

            userChoice = getUserChoice(systemFormId, bankKey, airKey, (String) responseMap.get(
                    ItemResponseConstants.ITEM_RESPONSE_ID), responseValue);

            responseMap.put(ItemResponseConstants.ITEM_RESPONSE_CBCHOICEIDENTIFIER, userChoice);

        }
    }

    @SuppressWarnings("unchecked")
    private Object getUserChoice(String systemFormID, String bankKey, String airKey, String responseId,
            Object responseValue)
    {
        Map<String, ?> itemCrosswalk = itemResponseDAO.getItemCrosswalk(systemFormID, bankKey, airKey, responseId);

        String interactionType = (String) itemCrosswalk.get("interactionType");

        if (interactionType.equals(ItemResponseConstants.ITEM_TYPE_TEXT_INTERACTION))
        {
            return String.format("%-4s", responseValue);
        } else if (interactionType.equals(ItemResponseConstants.ITEM_TYPE_CHOICE_INTERACTION))
        {
            
            List<LinkedHashMap<?, ?>> choiceIdentifiers = (List<LinkedHashMap<?, ?>>) itemCrosswalk.get(
                    "choiceIdentifiers");
            String airChoiceIdentifier = null;
            String cbChoiceIdentifier = null;
            for (LinkedHashMap<?, ?> choiceIdentifier : choiceIdentifiers)
            {
                airChoiceIdentifier = (String) choiceIdentifier.get("airChoiceIdentifier");
                if (airChoiceIdentifier.equals(responseValue))
                {
                    cbChoiceIdentifier = (String) choiceIdentifier.get("cbChoiceIdentifier");
                    break;
                }
            }

            if (cbChoiceIdentifier == null)
            {
                throw new RuntimeException(String.format(
                        "Invalid responseValue.systemFormID:%s,bankKey:%s,airKey:%s,responseId:%s,responseValue:%s",
                        systemFormID, bankKey, airKey, responseId, responseValue));
            } else
            {
                return cbChoiceIdentifier.substring(1);
            }

        } else
        {
            throw new RuntimeException("Invalid interactionType:" + interactionType);
        }

    }

    private void updateSourceFormCode(DocumentContext metadata, DocumentContext inputJsonDoc, String systemFormId)
    {
        String sourceFormCd = null;
        String ssdFlag = null;
        String accomodationCd = getAccomodation(metadata, inputJsonDoc);
        if (accomodationCd == null)
        {
            ssdFlag = "N";
        } else
        {
            ssdFlag = "Y";
        }

        Integer asmtId = inputJsonDoc.read(ItemResponseConstants.ASMT_ID_JPATH);
        if (accomodationCd != null || asmtId.intValue() == 99)
        {

            Integer eventId = (Integer) getTesteeAttributeValue(inputJsonDoc,
                    ItemResponseConstants.TESTEEATTR_NAME_EVENT_ID);
            Integer asmtSubType = inputJsonDoc.read(ItemResponseConstants.ASMT_SUB_TYPE_JPATH);

            String registrationsURL = String.format(bsAssessInfoURL +
                                                    "assessments/forms/sourceFormId/%s/siblings?" +
                                                    "eventId=%s&deliveryPlatformCd=1&asmtSubtypeCd=%s",
                    systemFormId, eventId.toString(), asmtSubType);

            if (accomodationCd == null)
            {
                registrationsURL = registrationsURL + "&excludeFormsWithAccomodations=Y";
            } else
            {
                registrationsURL = registrationsURL + "&asmtFormAccommodationTypeCds=" + accomodationCd;
            }


            DMFHttpClient httpClient = new DMFHttpClient();
            DMFHttpResponse response = httpClient.doGet(registrationsURL, bsAssessInfoURLMediaType,
                    DMFConstants.DMF_CLOUD_SOA_PREFIX);

            if (!DMFHttpClient.isSuccess(response.getStatusCode()))
            {
                throw new RuntimeException("Error in service call");
            }

            Configuration configuration = DMFUtils.getJsonParserConfiguration();
            DocumentContext responseDocContext = JsonPath.parse(response.getResponseJson(), configuration);
            sourceFormCd = responseDocContext.read(ItemResponseConstants.ASSINFO_RESP_SOURCE_FORM_ID_JPATH);
            if (sourceFormCd == null)
            {
                throw new RuntimeException("Invalid sourceFormCd. sourceFormCd" + sourceFormCd);
            }
        } else
        {
            sourceFormCd = systemFormId;
        }
        inputJsonDoc.put("$", ItemResponseConstants.SSD_FLAG_KEY, ssdFlag);
        inputJsonDoc.put("$", ItemResponseConstants.SOURCE_FORM_CD_KEY, sourceFormCd);

    }    

    private String getAccomodation(DocumentContext metadata, DocumentContext inputJsonDoc)
    {
        String accomodationValue = (String) getTesteeAttributeValue(inputJsonDoc,
                ItemResponseConstants.TESTEEATTR_NAME_CB_ACCOMMODATION);

        String accomodationCd = null;
        if (ItemResponseConstants.STATE_APPROVED_ACCOM_VALUE.equals(accomodationValue))
        {
            accomodationCd = ItemResponseConstants.STATE_APPROVED_ACCOM_CD;
        } else if (ItemResponseConstants.CB_DIGITAL_ACCOM_VALUE.equals(accomodationValue))
        {
            accomodationCd = ItemResponseConstants.CB_DIGITAL_ACCOM_CD;
        } else if (accomodationHasNonDefaultCode(metadata, inputJsonDoc))
        {
            accomodationCd = ItemResponseConstants.CB_DIGITAL_ACCOM_CD;
        } else if ("Y".equals(getTesteeAttributeValue(inputJsonDoc,
                ItemResponseConstants.TESTEEATTR_NAME_CB_NON_EMBEDDED_ACCOMMODATION)))
        {
            accomodationCd = ItemResponseConstants.CB_DIGITAL_ACCOM_CD;
        }

        return accomodationCd;
    }


    @SuppressWarnings("unchecked")
    private boolean accomodationHasNonDefaultCode(DocumentContext metadata, DocumentContext inputJsonDoc)
    {
        List<LinkedHashMap<?, ?>> accomodations = metadata.read(ItemResponseConstants.METADATA_ACCOMMODATIONS_JPATH);

        if (accomodations == null)
        {
            return false;
        }

        String accommodationType = null;
        List<String> defaultCodes = null;
        List<String> inputAccommodationCodes = null;
        Filter accommodationFilter = null;
        for (LinkedHashMap<?, ?> accomodation : accomodations)
        {
            accommodationType = (String) accomodation.get(ItemResponseConstants.METADATA_ACCOMMODATION_TYPE_KEY);
            defaultCodes = (List<String>) accomodation.get(
                    ItemResponseConstants.METADATA_ACCOMMODATION_DEFAULTCODES_KEY);

            accommodationFilter = Filter.filter(Criteria.where(ItemResponseConstants.ACCOMMODATION_TYPE_KEY).is(
                    accommodationType));
            inputAccommodationCodes = inputJsonDoc.read(ItemResponseConstants.ACCOMMODATIONCODE_JPATH,
                    accommodationFilter);


            if (inputAccommodationCodes==null || inputAccommodationCodes.isEmpty())
            {
                //inputJson doesn't have any record of this accommodation type. So continue to next accommodation type
                continue;
            }
            
            for (String inputAccommodationCode : inputAccommodationCodes)
            {
                //Check if inputAccommodationCode is a defaultAccommodationCode or not 
                if (!defaultCodes.contains(inputAccommodationCode))
                {
                    LOGGER.info("Accomodation type {} has NonDefaultCode {}", accommodationType,
                            inputAccommodationCode);

                    return true;
                }
            }
        }
        return false;
    }
    
    private boolean isFormLevelQCFlagApplied(Integer eventId, String airkey, Integer asmtId, String sysFrmCd)
    {
    	boolean QCFlagA = false;
    	
    	//get if record exists for this eventId & formId
    	
    	String qcId = eventId + ItemResponseConstants.SEPARATOR_COLN + sysFrmCd;    	
    	Map<String, ?> qcItem = itemResponseDAO.getQcFlagItem(qcId);
    	//if exists
    	if(qcItem != null)
    	{
    		//check if airkey already exists    		
    		//if exists
    		@SuppressWarnings("unchecked")
			List<String> airKeys = (List<String>) qcItem.get("airKeys");
    		if(airKeys.contains(airkey))
    		{
    			
    			QCFlagA = true;
    			
    		}else{//else
    			
    			//check if it's status as N
    			String status = (String) qcItem.get("qcComplete");
    			if(ItemResponseConstants.QC_FLAG_STATUS_N.equalsIgnoreCase(status))
    			{//if status is N
    			
    				//update the record    				
    				QCFlagA = itemResponseDAO.updateQcFlagItem(qcId, asmtId, airkey, ItemResponseConstants.QC_FLAG_VERSION_1);
    				
    			}
    			
    		}
    		
    	}else {//else
    		//insert the record    		
    		QCFlagA = itemResponseDAO.insertQcFlagItem(qcId, airkey, ItemResponseConstants.QC_FLAG_VERSION_1, 
    				ItemResponseConstants.QC_FLAG_STATUS_N, asmtId);    		
    	}
    	return QCFlagA;
    }

    private boolean isEdLevelQCFlagApplied(Integer eventId, String airkey, Integer asmtId, String edLvlCd)
    {
    	boolean QCFlagC = false;
    	if(asmtId != null && (asmtId.intValue() == 100 || asmtId.intValue() == 102)) {
	    	//get if record exists for this eventId & EdLevelCd
    		String qcId = eventId + ItemResponseConstants.SEPARATOR_COLN + edLvlCd;
    		Map<String, ?> qcItem = itemResponseDAO.getQcFlagItem(qcId);
	    	//if exists
    		if(qcItem != null)
    		{
	    		//check if airkey already exists    			
	    		//if exists
	    			//return true
    			@SuppressWarnings("unchecked")
				List<String> airKeys = (List<String>) qcItem.get("airKeys");
        		if(airKeys.contains(airkey))
        		{        			
        			QCFlagC = true;        			
        		}
    			
    		}else{//else
	    	
    			//insert record
    			QCFlagC = itemResponseDAO.insertQcFlagItem(qcId, airkey, ItemResponseConstants.QC_FLAG_VERSION_1, 
						ItemResponseConstants.QC_FLAG_STATUS_Y, asmtId);
	    		//return true    			
    		}
    	}
    	return QCFlagC;
    }

}
