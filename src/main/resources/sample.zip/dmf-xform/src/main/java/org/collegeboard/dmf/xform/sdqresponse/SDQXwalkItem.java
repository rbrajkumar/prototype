package org.collegeboard.dmf.xform.sdqresponse;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class SDQXwalkItem
{
    private String questionIdentifier;
    private String interactionType;
    private List<ResponseIdentifier> responseIdentifiers;

    public String getQuestionIdentifier()
    {
        return questionIdentifier;
    }

    public void setQuestionIdentifier(String questionIdentifier)
    {
        this.questionIdentifier = questionIdentifier;
    }

    public String getInteractionType()
    {
        return interactionType;
    }

    public void setInteractionType(String interactionType)
    {
        this.interactionType = interactionType;
    }

    public List<ResponseIdentifier> getResponseIdentifiers()
    {
        return responseIdentifiers;
    }

    public void setResponseIdentifiers(List<ResponseIdentifier> responseIdentifiers)
    {
        this.responseIdentifiers = responseIdentifiers;
    }

}
