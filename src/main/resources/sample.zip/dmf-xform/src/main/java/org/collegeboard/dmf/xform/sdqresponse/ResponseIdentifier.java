package org.collegeboard.dmf.xform.sdqresponse;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ResponseIdentifier
{
    private String responseValueId;
    private String responseText;
    private String questionIdentifier;
    private String code;

    public String getResponseValueId()
    {
        return responseValueId;
    }
    public void setResponseValueId(String responseValueId)
    {
        this.responseValueId = responseValueId;
    }
    public String getResponseText()
    {
        return responseText;
    }
    public void setResponseText(String responseText)
    {
        this.responseText = responseText;
    }

    public String getQuestionIdentifier()
    {
        return questionIdentifier;
    }

    public void setQuestionIdentifier(String questionIdentifier)
    {
        this.questionIdentifier = questionIdentifier;
    }
    public String getCode()
    {
        return code;
    }
    public void setCode(String code)
    {
        this.code = code;
    }

}
