package org.collegeboard.dmf.xform.essayscore;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

public class RaterScore
{

    private String raterId;
    private Integer raterReadingScore;
    private Integer raterAnalysisScore;
    private Integer raterWritingScore;
    private List<String> essayCondition;
    private String raterTimestamp;

    @JsonProperty("RaterId")
    public String getRaterId()
    {
        return raterId;
    }

    public void setRaterId(String raterId)
    {
        this.raterId = raterId;
    }

    @JsonProperty("RaterReadingScore")
    public Integer getRaterReadingScore()
    {
        return raterReadingScore;
    }

    public void setRaterReadingScore(Integer raterReadingScore)
    {
        this.raterReadingScore = raterReadingScore;
    }

    @JsonProperty("RaterAnalysisScore")
    public Integer getRaterAnalysisScore()
    {
        return raterAnalysisScore;
    }

    public void setRaterAnalysisScore(Integer raterAnalysisScore)
    {
        this.raterAnalysisScore = raterAnalysisScore;
    }

    @JsonProperty("RaterWritingScore")
    public Integer getRaterWritingScore()
    {
        return raterWritingScore;
    }

    public void setRaterWritingScore(Integer raterWritingScore)
    {
        this.raterWritingScore = raterWritingScore;
    }

    @JsonProperty("EssayCondition")
    @JsonInclude(Include.NON_NULL)
    public List<String> getEssayCondition()
    {
        return essayCondition;
    }

    public void setEssayCondition(List<String> essayCondition)
    {
        this.essayCondition = essayCondition;
    }

    @JsonProperty("RaterTimestamp")
    public String getRaterTimestamp()
    {
        return raterTimestamp;
    }

    public void setRaterTimestamp(String raterTimestamp)
    {
        this.raterTimestamp = raterTimestamp;
    }

}
