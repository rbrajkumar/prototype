package org.collegeboard.dmf.xform;

import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.collegeboard.dmf.common.utils.DMFClientBuilder;

import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.GetItemSpec;
import com.jayway.jsonpath.DocumentContext;

public class XformDynamoDBDAO
{
    private static String stageXformMessageTBLName;
    private static String xformMetadataTBLName;

    static
    {
        stageXformMessageTBLName = System.getenv("DMF_STAGE_XFORM_MESSAGES_TABLE_NAME");
        xformMetadataTBLName = System.getenv("DMF_XFORM_SERVICE_METADATA_TABLE_NAME");
    }

    private final Table stageXformMessageTBL;
    private final Table xformMetadataTBL;

    public XformDynamoDBDAO()
    {
        DynamoDB dynamoDB = DMFClientBuilder.getDaxClient();
        stageXformMessageTBL = dynamoDB.getTable(stageXformMessageTBLName);
        xformMetadataTBL = dynamoDB.getTable(xformMetadataTBLName);
    }

    public void putXformJsonMessages(String messageIdentifier, Object xformResponse)
    {
        if (xformResponse != null)
        {
            Item item = new Item().withPrimaryKey("messageIdentifier", messageIdentifier);

            if (xformResponse instanceof DocumentContext)
            {
                String jsonStr = ((DocumentContext) xformResponse).jsonString();
                item.withJSON("xformResponse", jsonStr);
            } else
            {
                item.with("xformResponse", xformResponse);
            }

            stageXformMessageTBL.putItem(item);
        }
    }

    public Map<String, String> getMetadata(String messageTypeId)
    {
        GetItemSpec getItemSpec = new GetItemSpec().withAttributesToGet("xformServiceClass", "metadata").withPrimaryKey(
                "messageTypeId", messageTypeId);

        Item item = xformMetadataTBL.getItem(getItemSpec);

        if (item == null)
        {
            throw new RuntimeException("Item Not found");
        }

        Map<String, String> metadataMap = new HashedMap<String, String>();
        metadataMap.put("SERVICE_CLASS", item.getString("xformServiceClass"));
        metadataMap.put("METADATA", item.getJSON("metadata"));

        return metadataMap;
    }

}
