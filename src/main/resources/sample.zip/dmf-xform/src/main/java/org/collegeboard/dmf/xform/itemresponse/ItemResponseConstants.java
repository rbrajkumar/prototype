package org.collegeboard.dmf.xform.itemresponse;

public class ItemResponseConstants
{
    public static String TESTEEATTRVAL_JPATH = "$.tdsreport.testee.testeeattribute[?].value";
    public static String TESTEEATTR_NAME_KEY = "name";
    public static String TESTEEATTR_NAME_EVENT_ID = "EventID";
    public static String TESTEEATTR_NAME_EXTERNAL_ID = "ExternalID";
    public static String TESTEEATTR_NAME_CB_ACCOMMODATION = "CB_Accommodation";
    public static String TESTEEATTR_NAME_CB_NON_EMBEDDED_ACCOMMODATION = "CB_Non_Embedded_Accommodation";

    public static String ACCOMMODATIONCODE_JPATH = "$.tdsreport.opportunity.accommodation[?].code";
    public static String ACCOMMODATION_TYPE_KEY = "type";

    public static String CB_DIGITAL_ACCOM_VALUE = "CB";
    public static String CB_DIGITAL_ACCOM_CD = "9";
    public static String STATE_APPROVED_ACCOM_VALUE = "SAA";
    public static String STATE_APPROVED_ACCOM_CD = "6";

    public static String START_DATE_JPATH = "$.startDate";
    public static String FORM_ID_JPATH = "$.tdsreport.opportunity.segment[0].formID";
    public static String AIRKEY_JPATH = "$.tdsreport.testee.airkey";
    public static String SYSTEM_FORM_ID_KEY = "systemFormId";
    public static String SOURCE_FORM_CD_KEY = "sourceFormCd";
    public static String SSD_FLAG_KEY = "ssdFlag";

    public static String ASMT_RESP_ASMT_ID_JPATH = "$.AsmtRegistration[0].assessmentEvent.assessment.asmtId";
    public static String ASMT_RESP_ASMT_SUB_TYP_CD_JPATH =
            "$.AsmtRegistration[0].assessmentEvent.assessment.asmtSubType.code";
    public static String ASMT_RESP_AI_CD_JPATH = "$.AsmtRegistration[0].aiCode";
    public static String ASMT_RESP_PERSON_ID_JPATH = "$.AsmtRegistration[0].personId";
    public static String ASMT_RESP_ED_LEVEL_CD_JPATH = "$.AsmtRegistration[0].educationLevel.code";

    public static String ASSINFO_RESP_SOURCE_FORM_ID_JPATH = "$.forms[0].sourceFormId";

    public static String ITEM_JPATH = "$.tdsreport.opportunity.item[?(@.response[1].itemResponse)]";
    public static String ITEM_BANKKEY = "bankkey";
    public static String ITEM_AIRKEY = "airkey";
    public static String ITEM_MAINRESPONSE = "response";
    public static String ITEM_ITEM_RESPONSE = "itemResponse";
    public static String ITEM_RESPONSE = "response";
    public static String ITEM_RESPONSE_ID = "id";
    public static String ITEM_RESPONSE_VALUE = "value";
    public static String ITEM_TYPE_CHOICE_INTERACTION = "choiceInteraction";
    public static String ITEM_TYPE_TEXT_INTERACTION = "textEntryInteraction";
    public static String ITEM_RESPONSE_CBCHOICEIDENTIFIER = "cbChoiceIdentifier";

    public static String ASMT_KEY = "assessment";
    public static String NAQ_MTDT_MAP_KEY = "naqMetadataMap";
    public static String ATND_AI_CD_KEY = "attendingAiCode";
    public static String PERSON_ID_KEY = "personId";
    public static String ASMT_SUB_TYPE_CD = "asmtSubTypeCd";
    public static String ASMT_SUB_TYPE_JPATH = "$.asmtSubTypeCd";
    public static String ASMT_ID = "asmtId";
    public static String ASMT_ID_JPATH = "$.asmtId";
    public static String ED_LEVEL_CD = "edLevelCd";
    
    public static String ADMIN_DATE_SRF_KEY = "adminDateSRF";
    public static String ADMIN_YR_KEY = "adminYear";
    public static String ADMIN_MONTH_KEY = "adminMonth";
    public static String ADMIN_DAY_KEY = "adminDay";

    public static String ADMIN_DATE_SRF_AIR_FORMAT = "yyyy-MM-dd";
    public static String ADMIN_DATE_SRF_CB_FORMAT = "MMddyyyy";

    public static String NAQ_MTDT_MAP_RSAT_ESSAY = "Digital rSAT Essay";
    public static String NAQ_MTDT_MAP_DIGI_RSAT = "Digital rSAT";
    public static String NAQ_MTDT_MAP_DIGI_PSAT_10 = "Digital PSAT 10";
    public static String NAQ_MTDT_MAP_DIGI_PSAT_8_9 = "Digital PSAT8/9";

    public static String ASMT_RSAT_ESSAY = "1";
    public static String ASMT_DIGI_RSAT = "2";
    public static String ASMT_DIGI_PSAT_10 = "3";
    public static String ASMT_DIGI_PSAT_8_9 = "4";

    public static String METADATA_ACCOMMODATIONS_JPATH = "$.accommodations";
    public static String METADATA_ACCOMMODATION_TYPE_KEY = "type";
    public static String METADATA_ACCOMMODATION_DEFAULTCODES_KEY = "defaultCodes";
    public static String METADATA_ACCOMMODATION_CODE_KEY = "code";
    
    public static String SEPARATOR_COLN = ":";
    
    public static String QC_FLAG_KEY = "qcFlag";
    public static String QC_FLAG_A = "A";
    public static String QC_FLAG_C = "C";
    public static String QC_FLAG_N = "N";
    public static String QC_FLAG_STATUS_Y = "Y";
    public static String QC_FLAG_STATUS_N = "N";
    public static String QC_FLAG_VERSION_1 = "1";
    public static String QC_FLAG_VERSION_2 = "2";
}
