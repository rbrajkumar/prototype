package org.collegeboard.dmf.xform.essayscore;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SequenceRaterScore
{
    private String messageTopicVersionId;
    private String recordType;
    private String uin;
    private String sourceEssayFormId;
    private Integer raterSequenceNumber;
    private RaterScore raterScore;
    private String scoreMethod;
    private Integer appId;
    private String messageTimeStamp;

    @JsonProperty("MessageTopicVersionId")
    public String getMessageTopicVersionId()
    {
        return messageTopicVersionId;
    }

    public void setMessageTopicVersionId(String messageTopicVersionId)
    {
        this.messageTopicVersionId = messageTopicVersionId;
    }

    @JsonProperty("RecordType")
    public String getRecordType()
    {
        return recordType;
    }

    public void setRecordType(String recordType)
    {
        this.recordType = recordType;
    }

    @JsonProperty("UIN")
    public String getUin()
    {
        return uin;
    }

    public void setUin(String uin)
    {
        this.uin = uin;
    }

    @JsonProperty("SourceEssayFormId")
    public String getSourceEssayFormId()
    {
        return sourceEssayFormId;
    }

    public void setSourceEssayFormId(String sourceEssayFormId)
    {
        this.sourceEssayFormId = sourceEssayFormId;
    }

    @JsonProperty("RaterSequenceNumber")
    public Integer getRaterSequenceNumber()
    {
        return raterSequenceNumber;
    }

    public void setRaterSequenceNumber(Integer raterSequenceNumber)
    {
        this.raterSequenceNumber = raterSequenceNumber;
    }

    @JsonProperty("Rater")
    public RaterScore getRaterScore()
    {
        return raterScore;
    }

    public void setRaterScore(RaterScore raterScore)
    {
        this.raterScore = raterScore;
    }

    @JsonProperty("ScoreMethod")
    public String getScoreMethod()
    {
        return scoreMethod;
    }

    public void setScoreMethod(String scoreMethod)
    {
        this.scoreMethod = scoreMethod;
    }

    @JsonProperty("AppId")
    public Integer getAppId()
    {
        return appId;
    }

    public void setAppId(Integer appId)
    {
        this.appId = appId;
    }
    
    @JsonProperty("MessageTimeStamp")
	public String getMessageTimeStamp() {
		return messageTimeStamp;
	}

	public void setMessageTimeStamp(String messageTimeStamp) {
		this.messageTimeStamp = messageTimeStamp;
	}
}
