package org.collegeboard.dmf.xform.sdqresponse;

import org.collegeboard.dmf.common.utils.DMFClientBuilder;

import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.GetItemSpec;
import com.fasterxml.jackson.databind.ObjectMapper;

public class SDQResponseXformDynmaoDAO
{
    private static String sdqCrosswalkTBLName;

    static
    {
        sdqCrosswalkTBLName = System.getenv("DMF_SDQ_CROSSWALK_TABLE_NAME");
    }

    private Table sdqCrosswalkTBL;

    public SDQResponseXformDynmaoDAO()
    {
        DynamoDB dynamoDB = DMFClientBuilder.getDaxClient();
        sdqCrosswalkTBL = dynamoDB.getTable(sdqCrosswalkTBLName);
    }

    public SDQXwalkItem getSdqCrosswalk(String airBankKey, String airItemId,
            String responseId)
    {
        String sdqIdentifier = null;
        try
        {
            sdqIdentifier = airBankKey + ":" + airItemId;
            GetItemSpec getItemSpec = new GetItemSpec()
                    .withPrimaryKey("sdqIdentifier", sdqIdentifier, "responseId", responseId)
                    .withAttributesToGet("interactionType","questionIdentifier","responseIdentifiers");

            Item item = sdqCrosswalkTBL.getItem(getItemSpec);
            return new ObjectMapper().readValue(item.toJSON(), SDQXwalkItem.class);
        } catch (Exception ex)
        {
            throw new RuntimeException(String.format(
                    "Error in getting SDQ Crosswalk for sdqIdentifier:%s, responseId:%s",
                    sdqIdentifier, responseId), ex);
        }
    }

}
