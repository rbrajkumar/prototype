package org.collegeboard.dmf.xform.essayscore;

public class ScoreReader
{
    private Integer readerSequence;
    private String readerId;
    private Integer readerScore;
    private String readerScoreVersion;
    private String readerScoreDate;

    public Integer getReaderSequence()
    {
        return readerSequence;
    }

    public void setReaderSequence(Integer readerSequence)
    {
        this.readerSequence = readerSequence;
    }

    public String getReaderId()
    {
        return readerId;
    }

    public void setReaderId(String readerId)
    {
        this.readerId = readerId;
    }

    public Integer getReaderScore()
    {
        return readerScore;
    }

    public void setReaderScore(Integer readerScore)
    {
        this.readerScore = readerScore;
    }

    public String getReaderScoreVersion()
    {
        return readerScoreVersion;
    }

    public void setReaderScoreVersion(String readerScoreVersion)
    {
        this.readerScoreVersion = readerScoreVersion;
    }

    public String getReaderScoreDate()
    {
        return readerScoreDate;
    }

    public void setReaderScoreDate(String readerScoreDate)
    {
        this.readerScoreDate = readerScoreDate;
    }

}
