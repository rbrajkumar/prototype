package org.collegeboard.dmf.xform.essayscore;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections4.ListUtils;
import org.collegeboard.dmf.common.utils.DMFConstants;
import org.collegeboard.dmf.xform.XformRequest;
import org.collegeboard.dmf.xform.XformService;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;

public class EssayScoreXformService implements XformService
{
    private static final String TOPIC_VERSION_ID = "1.0.0";
    private static final String RECORD_TYPE = "INS";

    private static final String STAGING_MSG_SCORE_DATE_FORMAT = "MMddyyyyHHmmss";
    private static final String STAGING_MSG_READER_SCORE_DATE_FORMAT = "MMddyyyy";

    private static final String SCORING_MSG_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";

    private static final String WRITING_SCORE_NAME = "ESSAYW";
    private static final String READING_SCORE_NAME = "ESSAYR";
    private static final String ANALYSIS_SCORE_NAME = "ESSAYA";

    private final ObjectMapper mapper;

    public EssayScoreXformService()
    {
        mapper = new ObjectMapper();
    }

    @Override
    public Map<String, String> transform(XformRequest xformRequest, DocumentContext metadata, String jsonMessage)
    {
        Map<String, String> responseMessages = new HashMap<>();
        try
        {
            EssayScore essayScore = mapper.readValue(jsonMessage, EssayScore.class);

            Collection<SequenceRaterScore> sequenceRaterScores = buildSequenceRaterScores(essayScore);

            for (SequenceRaterScore sequenceRaterScore : sequenceRaterScores)
            {
                responseMessages.put("RATER_SCORE" + sequenceRaterScore.getRaterSequenceNumber(), mapper
                        .writeValueAsString(sequenceRaterScore));
            }

            FinalTier finalTier = buildFinalTier(essayScore);
            responseMessages.put("FINAL_SCORE", mapper.writeValueAsString(finalTier));

        } catch (Exception ex)
        {
            throw new RuntimeException(ex);
        }        
        return responseMessages;
    }

    private Collection<SequenceRaterScore> buildSequenceRaterScores(EssayScore essayScore)
    {
        Map<Integer, SequenceRaterScore> sequenceRaterScoreMap = new HashMap<>();
        for (ScoreTier scoreTier : ListUtils.emptyIfNull(essayScore.getScoreTiers()))
        {
            updateSequenceRaterScore(essayScore.getUin(), scoreTier,
                    sequenceRaterScoreMap);
        }
        return sequenceRaterScoreMap.values();
    }

    private void updateSequenceRaterScore(String uin, ScoreTier scoreTier,
            Map<Integer, SequenceRaterScore> sequenceRaterScoreMap)
    {
        SequenceRaterScore sequenceRaterScore = null;

        for (ScoreReader scoreReader : ListUtils.emptyIfNull(scoreTier.getScoreReaders()))
        {
            sequenceRaterScore=sequenceRaterScoreMap.get(scoreReader.getReaderSequence());
            if(sequenceRaterScore==null){
                sequenceRaterScore = getRaterScoreDetails(uin, scoreTier.getEssayFormCode(), scoreTier
                        .getScoreMethodCode(),
                        scoreReader);
                sequenceRaterScoreMap.put(scoreReader.getReaderSequence(), sequenceRaterScore);
            }
            
            updateRaterScore(sequenceRaterScore.getRaterScore(), scoreTier.getScoreName(), scoreReader
                    .getReaderScore());
        }
    }

    private void updateRaterScore(RaterScore raterScore, String scoreName, int score)
    {
        if (WRITING_SCORE_NAME.equals(scoreName))
        {
            raterScore.setRaterWritingScore(score);
        } else if (READING_SCORE_NAME.equals(scoreName))
        {
            raterScore.setRaterReadingScore(score);
        } else if (ANALYSIS_SCORE_NAME.equals(scoreName))
        {
            raterScore.setRaterAnalysisScore(score);
        } else
        {
            throw new RuntimeException(String.format("Invalid Score Name:%s", scoreName));
        }
    }

    private SequenceRaterScore getRaterScoreDetails(String uin, String essayFormCode, String scoreMethod,
            ScoreReader scoreReader)
    {
        SequenceRaterScore raterScoreDetails = new SequenceRaterScore();
        raterScoreDetails.setAppId(DMFConstants.DMF_APP_ID);
        raterScoreDetails.setSourceEssayFormId(essayFormCode);
        raterScoreDetails.setMessageTopicVersionId(TOPIC_VERSION_ID);
        raterScoreDetails.setRecordType(RECORD_TYPE);
        raterScoreDetails.setUin(uin);
        raterScoreDetails.setRaterSequenceNumber(scoreReader.getReaderSequence());
        raterScoreDetails.setScoreMethod(scoreMethod);

        RaterScore raterScore = new RaterScore();
        raterScore.setRaterId(scoreReader.getReaderId());
        raterScore.setRaterTimestamp(convertToScoringDateFromat(scoreReader.getReaderScoreDate(),
                STAGING_MSG_READER_SCORE_DATE_FORMAT));
        raterScoreDetails.setRaterScore(raterScore);
        raterScoreDetails.setMessageTimeStamp(getCurrentTimeStamp());

        return raterScoreDetails;
    }

    private FinalTier buildFinalTier(EssayScore essayScore)
    {
        FinalTier finalTier = new FinalTier();
        finalTier.setMessageTopicVersionId(TOPIC_VERSION_ID);
        finalTier.setAppId(DMFConstants.DMF_APP_ID);
        finalTier.setRecordType(RECORD_TYPE);
        finalTier.setUin(essayScore.getUin());
        Set<String> essayCondition = new HashSet<>();

        int i = 0;
        for (ScoreTier scoreTier : ListUtils.emptyIfNull(essayScore.getScoreTiers()))
        {
            if (i == 0)
            {
                finalTier.setScoreMethod(scoreTier.getScoreMethodCode());
                finalTier.setSourceEssayFormId(scoreTier.getEssayFormCode());
            }

            if (WRITING_SCORE_NAME.equals(scoreTier.getScoreName()))
            {
                finalTier.setFinalWritingEssayScore(scoreTier.getScore());
            } else if (READING_SCORE_NAME.equals(scoreTier.getScoreName()))
            {
                finalTier.setFinalReadingEssayScore(scoreTier.getScore());
            } else if (ANALYSIS_SCORE_NAME.equals(scoreTier.getScoreName()))
            {
                finalTier.setFinalAnalysisEssayScore(scoreTier.getScore());
            } else
            {
                throw new RuntimeException(String.format("Invalid Score Name:%s", scoreTier.getScoreName()));
            }
            if (scoreTier.getEssayConditionCode() != null && scoreTier.getEssayConditionCode().length() > 0)
            {
                essayCondition.add(scoreTier.getEssayConditionCode());
            }
            i++;
        }

        if (essayCondition.size() > 0)
        {
            finalTier.setEssayCondition(essayCondition);
        }

        finalTier.setRawScoreTimeStamp(getRawScoreTimeStamp(essayScore.getScoreTiers()));
        finalTier.setMessageTimeStamp(getCurrentTimeStamp());
        return finalTier;
    }

    private String getRawScoreTimeStamp(List<ScoreTier> scoreTiers)
    {
        List<String> scoreTimeStamps = new ArrayList<>();
        for (ScoreTier scoreTier : scoreTiers)
        {
            scoreTimeStamps.add(scoreTier.getScoreTimeStamp());
        }

        Collections.sort(scoreTimeStamps, new Comparator<String>()
        {
            DateFormat dateFormat = new SimpleDateFormat(STAGING_MSG_SCORE_DATE_FORMAT);

            @Override
            public int compare(String o1, String o2)
            {
                try
                {
                    return dateFormat.parse(o1).compareTo(dateFormat.parse(o2));
                } catch (ParseException e)
                {
                    throw new IllegalArgumentException(e);
                }
            }
        });
        String latestScoreTimeStamp = scoreTimeStamps.get(scoreTimeStamps.size() - 1);

        return convertToScoringDateFromat(latestScoreTimeStamp, STAGING_MSG_SCORE_DATE_FORMAT);
    }

    private String convertToScoringDateFromat(String sourceDateStr, String sourceDateFormat)
    {
        SimpleDateFormat stagingMsgDateFormat = new SimpleDateFormat(sourceDateFormat);
        SimpleDateFormat scoringMsgDateFormat = new SimpleDateFormat(SCORING_MSG_DATE_FORMAT);

        try
        {
            Date sourcedDate = stagingMsgDateFormat.parse(sourceDateStr);
            return scoringMsgDateFormat.format(sourcedDate);
        } catch (Exception ex)
        {
            throw new RuntimeException(String.format("Error in date Conversion. Source date:%s", sourceDateStr), ex);
        }
    }
    
    private String getCurrentTimeStamp()
    {
    	return ZonedDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern(SCORING_MSG_DATE_FORMAT));
    }

}
