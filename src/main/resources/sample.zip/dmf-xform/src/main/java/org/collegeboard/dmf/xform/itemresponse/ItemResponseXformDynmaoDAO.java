package org.collegeboard.dmf.xform.itemresponse;

import java.util.Map;

import org.collegeboard.dmf.common.utils.DMFClientBuilder;

import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.GetItemSpec;
import com.amazonaws.services.dynamodbv2.document.spec.PutItemSpec;
import com.amazonaws.services.dynamodbv2.document.spec.UpdateItemSpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.ConditionalCheckFailedException;
import com.amazonaws.services.dynamodbv2.model.ReturnValue;

public class ItemResponseXformDynmaoDAO
{
    private static String itemCrosswalkTBLName;
    private static String qcFlagReferTBLName;

    static
    {
        itemCrosswalkTBLName = System.getenv("DMF_ITEM_CROSSWALK_TABLE_NAME");
        qcFlagReferTBLName = System.getenv("DMF_ITEM_QC_FLAG_TABLE_NAME");
    }

    private Table itemCrosswalkTBL;
    private Table qcFlagReferTBL;

    public ItemResponseXformDynmaoDAO()
    {
        DynamoDB dynamoDB = DMFClientBuilder.getDaxClient();
        itemCrosswalkTBL = dynamoDB.getTable(itemCrosswalkTBLName);
        qcFlagReferTBL = dynamoDB.getTable(qcFlagReferTBLName);
    }

    public Map<String, ?> getItemCrosswalk(String systemFormId, String airBankKey, String airItemId,
            String responseId)
    {
        String itemResponseIdentifier = airBankKey + ":" + airItemId + ":" + responseId;
        GetItemSpec getItemSpec = new GetItemSpec()
                .withPrimaryKey("systemFormId", systemFormId, "itemResponseIdentifier", itemResponseIdentifier)
                .withAttributesToGet("interactionType", "choiceIdentifiers");

        Item item = itemCrosswalkTBL.getItem(getItemSpec);
        if (item == null)
        {
            throw new RuntimeException(String.format(
                    "Item Crosswalk not found for systemFormId:%s, itemResponseIdentifier:%s", systemFormId,
                    itemResponseIdentifier));
        }
        return itemCrosswalkTBL.getItem(getItemSpec).asMap();
    }
    
	public Map<String, ?> getQcFlagItem(String qcId) {
		GetItemSpec getItemSpec = new GetItemSpec().withPrimaryKey("qcIdentifier", qcId);
		Item item = qcFlagReferTBL.getItem(getItemSpec);
		return (null != item) ? item.asMap() : null;
	}
	
	public boolean insertQcFlagItem(String qcId, String airkey, String versionId, String flag, Integer assmntId) {
		Item qcItem = new Item()
        		.withPrimaryKey("qcIdentifier", qcId)
			    .withString("versionId", versionId)
			    .withString("qcComplete", flag)
			    .withInt("assessmentId", assmntId)
			    .withList("airKeys", airkey);
		
        PutItemSpec putItem = new PutItemSpec()
        		.withItem(qcItem)
        		.withConditionExpression("attribute_not_exists(qcIdentifier)");
		try
		{
			qcFlagReferTBL.putItem(putItem);
		}catch (ConditionalCheckFailedException ccfe) {
			
			return false;
			
		}
        
        
       return true;
	}
	
	public boolean updateQcFlagItem(String qcId, Integer assmntId, String airkey, String currentVersion) {
		UpdateItemSpec updateItemSpec = new UpdateItemSpec().withPrimaryKey("qcIdentifier", qcId)
    			.withUpdateExpression("set qcComplete=:qcComplete, assessmentId=:assmntId, versionId=:versionId, airKeys[1]=:airkey")
                .withConditionExpression("qcComplete <> N AND contains(versionId, :current)")
                .withValueMap(new ValueMap()
                		.withString(":qcComplete", "Y")
                		.withInt(":assmntId", assmntId)
                		.withString(":airkey", airkey)
                		.withString(":current", currentVersion)
                		.withString(":versionId", "2"))
                .withReturnValues(ReturnValue.UPDATED_NEW);
		
		boolean isSuccess = true;
		try {
			qcFlagReferTBL.updateItem(updateItemSpec);
		} catch (ConditionalCheckFailedException ccfe) {
			isSuccess = false;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return isSuccess;
	}
}