package org.collegeboard.dmf.xform.sdqresponse;

public class SDQResponseConstants
{
    public static String INTERACTION_TYPE_CHOICE = "choiceInteraction";
    public static String INTERACTION_TYPE_INLINECHOICE = "inlineChoiceInteraction";
    public static String INTERACTION_TYPE_MATCH = "matchInteraction";
    public static String INTERACTION_TYPE_TEXT = "textEntryInteraction";
    public static String INTERACTION_TYPE_EXTENDED_TEXT = "extendedTextInteraction";
    public static String INTERACTION_TYPE_TREE = "tree";

    public static String ITEM_JPATH = "$.tdsreport.opportunity.item[?(@.response[1].itemResponse)]";
    public static String ITEM_BANKKEY = "bankkey";
    public static String ITEM_AIRKEY = "airkey";
    public static String ITEM_MAINRESPONSE = "response";
    public static String ITEM_ITEM_RESPONSE = "itemResponse";
    public static String ITEM_RESPONSE = "response";
    public static String ITEM_RESPONSE_ID = "id";
    public static String ITEM_RESPONSE_VALUE = "value";

    public static String ITEM_RESPONSE_NAQS = "naqs";
}
