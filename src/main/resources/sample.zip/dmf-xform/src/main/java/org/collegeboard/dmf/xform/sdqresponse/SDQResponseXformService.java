package org.collegeboard.dmf.xform.sdqresponse;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.collegeboard.dmf.common.utils.DMFUtils;
import org.collegeboard.dmf.xform.XformRequest;
import org.collegeboard.dmf.xform.XformService;
import org.collegeboard.dmf.xform.itemresponse.ItemResponseConstants;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

public class SDQResponseXformService implements XformService
{

    private SDQResponseXformDynmaoDAO sdqResponseDAO;

    public SDQResponseXformService()
    {
        sdqResponseDAO = new SDQResponseXformDynmaoDAO();
    }

    @Override
    public Object transform(XformRequest xformRequest, DocumentContext metadata, String jsonMessage)
    {
        DocumentContext inputJsonDoc = null;
        try
        {
            inputJsonDoc = JsonPath.parse(jsonMessage, DMFUtils.getJsonParserConfiguration());

            updateSDQResponseDetails(inputJsonDoc);
        } catch (Exception ex)
        {
            throw new RuntimeException(ex);
        }
        return inputJsonDoc.jsonString();
    }

    @SuppressWarnings("unchecked")
    private void updateSDQResponseDetails(DocumentContext inputJsonDoc)
    {
        List<?> responsesList = null;
        String bankKey = null;
        String airKey = null;
        Map<?, ?> mainResponseMap = null;
        Map<String, Object> itemresponseMap = null;
        Object userResponse = null;
        Map<String, Object> sdqMap = null;

        List<LinkedHashMap<String, ?>> items = inputJsonDoc.read(SDQResponseConstants.ITEM_JPATH);

        if (items == null)
        {
            return;
        }

        for (LinkedHashMap<String, ?> item : items)
        {
            sdqMap = new LinkedHashMap<>();
            bankKey = String.valueOf(item.get(ItemResponseConstants.ITEM_BANKKEY));
            airKey = String.valueOf(item.get(ItemResponseConstants.ITEM_AIRKEY));
            responsesList = (List<?>) item.get(SDQResponseConstants.ITEM_MAINRESPONSE);

            mainResponseMap = (LinkedHashMap<?, ?>) responsesList.get(1);
            itemresponseMap = (LinkedHashMap<String, Object>) mainResponseMap.get(
                    SDQResponseConstants.ITEM_ITEM_RESPONSE);
            userResponse = itemresponseMap.get(SDQResponseConstants.ITEM_RESPONSE);

            if (userResponse instanceof List)
            {
                //Item has mutliple responseIds
                processUserResponse(bankKey, airKey, (List<Map<String, Object>>) userResponse, sdqMap);
            } else
            {
                //Item has single responseId
                processUserResponse(bankKey, airKey, (Map<String, Object>) userResponse, sdqMap);
            }

            if (sdqMap.size() > 0)
            {
                itemresponseMap.put(SDQResponseConstants.ITEM_RESPONSE_NAQS, concatValues(sdqMap));
            }
        }
    }

    private void processUserResponse(String bankKey, String airKey,
            List<Map<String, Object>> responses, Map<String, Object> sdqMap)
    {
        for (Map<String, Object> response : responses)
        {
            processUserResponse(bankKey, airKey, response, sdqMap);
        }
    }

    private void updateUserResponseCode(List<ResponseIdentifier> responseIdentifiers, String userResponse,
            Map<String, Object> sdqMap)
    {
        ResponseIdentifier responseIdentifier = getResponseIdentifier(responseIdentifiers, userResponse);
        updateSDQMap(sdqMap, responseIdentifier.getQuestionIdentifier(), responseIdentifier.getCode());
    }

    private ResponseIdentifier getResponseIdentifier(List<ResponseIdentifier> responseIdentifiers, String response)
    {
        
        for (ResponseIdentifier responseIdentifier : responseIdentifiers)
        {
            if (response.equals(responseIdentifier.getResponseValueId()))
            {
                return responseIdentifier;
            }
        }
        throw new RuntimeException("Invalid response value:" + response);
    }

    private void updateSDQMap(Map<String, Object> sdqMap, String questionIdentifier, Object response)
    {
        Integer position = getValuePosition(questionIdentifier);
        if (position == null)
        {
            //questionIdentifier doesn't have any position information. So we need not to maintain response order.
            @SuppressWarnings("unchecked")
            List<Object> quesResponseList = (List<Object>) sdqMap.get(questionIdentifier);
            if (quesResponseList == null)
            {
                quesResponseList = new ArrayList<>();
                sdqMap.put(questionIdentifier, quesResponseList);
            }
            quesResponseList.add(response);
        } else
        {
            //questionIdentifier has position information. So we need to maintain response order.

            String questionIdentifierWithOutPosition = questionIdentifier.substring(0, questionIdentifier.lastIndexOf(
                    "["));

            Object[] quesResponseArray = (Object[]) sdqMap.get(questionIdentifierWithOutPosition);

            quesResponseArray = addValue(quesResponseArray, position - 1, response);
            sdqMap.put(questionIdentifierWithOutPosition, quesResponseArray);

        }

    }

    @SuppressWarnings("unchecked")
    private void processUserResponse(String bankKey, String airKey, Map<String, Object> responseMap,
            Map<String, Object> sdqMap)
    {
        String responseId = (String) responseMap.get(SDQResponseConstants.ITEM_RESPONSE_ID);
        SDQXwalkItem sdqCrosswalk = sdqResponseDAO.getSdqCrosswalk(bankKey, airKey, responseId);
        Object value = responseMap.get(SDQResponseConstants.ITEM_RESPONSE_VALUE);

        if (value == null || (value instanceof String && DMFUtils.isEmptyString((String) value)))
        {
            return;
        }

        if (sdqCrosswalk.getInteractionType().equals(SDQResponseConstants.INTERACTION_TYPE_TEXT) || 
                sdqCrosswalk.getInteractionType().equals(SDQResponseConstants.INTERACTION_TYPE_EXTENDED_TEXT))
        {
            updateSDQMap(sdqMap, sdqCrosswalk.getQuestionIdentifier(), value);
        } else if (sdqCrosswalk.getInteractionType().equals(SDQResponseConstants.INTERACTION_TYPE_TREE))
        {

            List<Object> tempList = null;
            if (value instanceof List)
            {
                tempList = (List<Object>) value;
            } else
            {
                tempList = new ArrayList<>();
                tempList.add(value.toString());
            }

            for (int i = 0; i < tempList.size(); i++)
            {
                     if(tempList.get(i)==null) {
                            continue;
                     }
                     
                ResponseIdentifier responseIdentifier = getResponseIdentifier(sdqCrosswalk.getResponseIdentifiers(),
                        tempList.get(i).toString());
                updateSDQMap(sdqMap, sdqCrosswalk.getQuestionIdentifier() + " " + (i + 1), responseIdentifier.getCode());
            }

        } else
        {
            if (value instanceof List)
            {
                //response has multiple values
                for (Object tmpVal : (List<Object>) value)
                {
                            if(tmpVal==null) {
                                   continue;
                            }
                    updateUserResponseCode(sdqCrosswalk.getResponseIdentifiers(), tmpVal.toString(), sdqMap);
                }

            } else
            {
                //response has single value
                updateUserResponseCode(sdqCrosswalk.getResponseIdentifiers(), value.toString(), sdqMap);
            }
        }
    }

    
    private static Object[] addValue(Object[] array, int index, Object value)
    {
        if (array == null)
        {
            array = new Object[10];
        }

        if (index > array.length - 1)
        {
            Object[] tmpArray = new Object[index + 10];
            System.arraycopy(array, 0, tmpArray, 0, array.length);
            array = tmpArray;

        }
        array[index] = value;

        return array;
    }

    private Integer getValuePosition(String questionIdentifier)
    {
        int arrayBeginIndex = questionIdentifier.lastIndexOf("[");
        if (arrayBeginIndex != -1 && questionIdentifier.endsWith("]"))
        {
            String indexStr = questionIdentifier.substring(arrayBeginIndex + 1, questionIdentifier.length() - 1);
            try
            {
                return Integer.parseInt(indexStr);
            } catch (NumberFormatException ex)
            {
                return null;
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> concatValues(Map<String, Object> sdqMap)
    {
        Map<String, Object> map = new LinkedHashMap<>();

        Object value = null;
        List<Object> valueList = null;

        for (Map.Entry<String, Object> entry : sdqMap.entrySet())
        {

            if (entry.getValue() instanceof Object[])
            {
                valueList = Arrays.asList((Object[]) entry.getValue());
            } else
            {
                valueList = (List<Object>) entry.getValue();
            }

            if (valueList.size() == 1)
            {
                value = valueList.get(0);
            } else
            {
                String tmpValStr = "";
                for (Object tmpVal : valueList)
                {
                    if (tmpVal != null)
                    {
                        tmpValStr = tmpValStr + tmpVal.toString();
                    }
                }
                if (DMFUtils.isEmptyString(tmpValStr))
                {
                    value = null;
                } else
                {
                    value = tmpValStr;
                }
            }
            map.put(entry.getKey(), value);
        }
        return map;
    }

}
