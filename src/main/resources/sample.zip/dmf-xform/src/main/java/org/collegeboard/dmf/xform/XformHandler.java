package org.collegeboard.dmf.xform;

import java.util.Map;

import org.collegeboard.dmf.common.dao.StageMessageInputDAO;
import org.collegeboard.dmf.common.utils.DMFConstants;
import org.collegeboard.dmf.common.utils.DMFKinesisLogger;
import org.collegeboard.dmf.common.utils.DMFUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

public class XformHandler implements RequestHandler<XformRequest, XformResponse>
{

    private static final Logger LOGGER = LoggerFactory.getLogger(XformHandler.class);

    private final XformDynamoDBDAO xformDAO;

    private static final String SERVICE_NAME = "Data Transformation";

    private static String env;

    private final StageMessageInputDAO stageMessageInputDAO;

    private final DMFKinesisLogger dmfKinesisLogger;

    static
    {
        env = System.getenv("ENVIRONMENT");
    }

    public XformHandler()
    {
        //TODO remove this after testing
        LOGGER.info("In Constructor:::");
        xformDAO = new XformDynamoDBDAO();
        dmfKinesisLogger = new DMFKinesisLogger();
        stageMessageInputDAO = new StageMessageInputDAO();
    }

    @Override
    public XformResponse handleRequest(XformRequest input, Context context)
    {
        //TODO remove this after testing
        LOGGER.info("In handler:::");
        XformResponse response = new XformResponse();

        DocumentContext kinesisMsgJson = null;
        try
        {
            kinesisMsgJson = dmfKinesisLogger.logServiceStart(input, env, SERVICE_NAME);

            String jsonMessage = stageMessageInputDAO.getInputMessage(input.getMessageIdentifier());

            Map<String, String> xformMetadata = xformDAO.getMetadata(input.getMessageType());

            DocumentContext metadata = null;
            if (!DMFUtils.isEmptyString(xformMetadata.get("METADATA")))
            {
                metadata = JsonPath.parse(xformMetadata.get("METADATA"), DMFUtils
                    .getJsonParserConfiguration());
            }

            XformService service = (XformService) Class.forName(xformMetadata.get("SERVICE_CLASS")).newInstance();
            Object responseMap = service.transform(input, metadata, jsonMessage);

            //load to db
            xformDAO.putXformJsonMessages(input.getMessageIdentifier(), responseMap);

            dmfKinesisLogger.logServiceSuccess(kinesisMsgJson, null);
            response.setStatus(DMFConstants.SERVICE_STATUS_SUCCESS);
        } catch (Throwable thr)
        {
            dmfKinesisLogger.logServiceError(kinesisMsgJson, thr);
            response.setStatus(DMFConstants.SERVICE_STATUS_ERROR);
        }
        return response;
    }

}
