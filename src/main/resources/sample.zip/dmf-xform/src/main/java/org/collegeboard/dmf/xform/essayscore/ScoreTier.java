package org.collegeboard.dmf.xform.essayscore;

import java.util.List;

public class ScoreTier
{
    private String scoreName;
    private String scoreValidIndicator;
    private Integer score;
    private String conversionMapVersion;
    private String scoreTimeStamp;
    private String scoreMethodCode;
    private String rightsCount;
    private String wrongsCount;
    private String omitsCount;
    private String multiGriddedCount;
    private String notReachedCount;
    private String essayFormCode;
    private String essayConditionCode;
    private Integer numberOfEssayReaders;
    private List<ScoreReader> scoreReaders;

    public String getScoreName()
    {
        return scoreName;
    }

    public void setScoreName(String scoreName)
    {
        this.scoreName = scoreName;
    }

    public String getScoreValidIndicator()
    {
        return scoreValidIndicator;
    }

    public void setScoreValidIndicator(String scoreValidIndicator)
    {
        this.scoreValidIndicator = scoreValidIndicator;
    }

    public Integer getScore()
    {
        return score;
    }

    public void setScore(Integer score)
    {
        this.score = score;
    }

    public String getConversionMapVersion()
    {
        return conversionMapVersion;
    }

    public void setConversionMapVersion(String conversionMapVersion)
    {
        this.conversionMapVersion = conversionMapVersion;
    }

    public String getScoreTimeStamp()
    {
        return scoreTimeStamp;
    }

    public void setScoreTimeStamp(String scoreTimeStamp)
    {
        this.scoreTimeStamp = scoreTimeStamp;
    }

    public String getScoreMethodCode()
    {
        return scoreMethodCode;
    }

    public void setScoreMethodCode(String scoreMethodCode)
    {
        this.scoreMethodCode = scoreMethodCode;
    }

    public String getRightsCount()
    {
        return rightsCount;
    }

    public void setRightsCount(String rightsCount)
    {
        this.rightsCount = rightsCount;
    }

    public String getWrongsCount()
    {
        return wrongsCount;
    }

    public void setWrongsCount(String wrongsCount)
    {
        this.wrongsCount = wrongsCount;
    }

    public String getOmitsCount()
    {
        return omitsCount;
    }

    public void setOmitsCount(String omitsCount)
    {
        this.omitsCount = omitsCount;
    }

    public String getMultiGriddedCount()
    {
        return multiGriddedCount;
    }

    public void setMultiGriddedCount(String multiGriddedCount)
    {
        this.multiGriddedCount = multiGriddedCount;
    }

    public String getNotReachedCount()
    {
        return notReachedCount;
    }

    public void setNotReachedCount(String notReachedCount)
    {
        this.notReachedCount = notReachedCount;
    }

    public String getEssayFormCode()
    {
        return essayFormCode;
    }

    public void setEssayFormCode(String essayFormCode)
    {
        this.essayFormCode = essayFormCode;
    }

    public String getEssayConditionCode()
    {
        return essayConditionCode;
    }

    public void setEssayConditionCode(String essayConditionCode)
    {
        this.essayConditionCode = essayConditionCode;
    }

    public Integer getNumberOfEssayReaders()
    {
        return numberOfEssayReaders;
    }

    public void setNumberOfEssayReaders(Integer numberOfEssayReaders)
    {
        this.numberOfEssayReaders = numberOfEssayReaders;
    }

    public List<ScoreReader> getScoreReaders()
    {
        return scoreReaders;
    }

    public void setScoreReaders(List<ScoreReader> scoreReaders)
    {
        this.scoreReaders = scoreReaders;
    }

}
