package org.collegeboard.dmf.xform.essayscore;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

public class FinalTier
{
    private String messageTopicVersionId;
    private String recordType;
    private String uin;
    private String sourceEssayFormId;
    private Integer finalReadingEssayScore;
    private Integer finalAnalysisEssayScore;
    private Integer finalWritingEssayScore;
    private Set<String> essayCondition;
    private String scoreMethod;
    private String rawScoreTimeStamp;
    private Integer appId;
    private String messageTimeStamp;

    @JsonProperty("MessageTopicVersionId")
    public String getMessageTopicVersionId()
    {
        return messageTopicVersionId;
    }

    public void setMessageTopicVersionId(String messageTopicVersionId)
    {
        this.messageTopicVersionId = messageTopicVersionId;
    }

    @JsonProperty("RecordType")
    public String getRecordType()
    {
        return recordType;
    }

    public void setRecordType(String recordType)
    {
        this.recordType = recordType;
    }

    @JsonProperty("UIN")
    public String getUin()
    {
        return uin;
    }

    public void setUin(String uin)
    {
        this.uin = uin;
    }

    @JsonProperty("SourceEssayFormId")
    public String getSourceEssayFormId()
    {
        return sourceEssayFormId;
    }

    public void setSourceEssayFormId(String sourceEssayFormId)
    {
        this.sourceEssayFormId = sourceEssayFormId;
    }

    @JsonProperty("FinalReadingEssayScore")
    public Integer getFinalReadingEssayScore()
    {
        return finalReadingEssayScore;
    }

    public void setFinalReadingEssayScore(Integer finalReadingEssayScore)
    {
        this.finalReadingEssayScore = finalReadingEssayScore;
    }

    @JsonProperty("FinalAnalysisEssayScore")
    public Integer getFinalAnalysisEssayScore()
    {
        return finalAnalysisEssayScore;
    }

    public void setFinalAnalysisEssayScore(Integer finalAnalysisEssayScore)
    {
        this.finalAnalysisEssayScore = finalAnalysisEssayScore;
    }

    @JsonProperty("FinalWritingEssayScore")
    public Integer getFinalWritingEssayScore()
    {
        return finalWritingEssayScore;
    }

    public void setFinalWritingEssayScore(Integer finalWritingEssayScore)
    {
        this.finalWritingEssayScore = finalWritingEssayScore;
    }

    @JsonProperty("EssayCondition")
    @JsonInclude(Include.NON_NULL)
    public Set<String> getEssayCondition()
    {
        return essayCondition;
    }

    public void setEssayCondition(Set<String> essayCondition)
    {
        this.essayCondition = essayCondition;
    }

    @JsonProperty("ScoreMethod")
    public String getScoreMethod()
    {
        return scoreMethod;
    }

    public void setScoreMethod(String scoreMethod)
    {
        this.scoreMethod = scoreMethod;
    }

    @JsonProperty("RawScoreTimeStamp")
    public String getRawScoreTimeStamp()
    {
        return rawScoreTimeStamp;
    }

    public void setRawScoreTimeStamp(String rawScoreTimeStamp)
    {
        this.rawScoreTimeStamp = rawScoreTimeStamp;
    }

    @JsonProperty("AppId")
    public Integer getAppId()
    {
        return appId;
    }

    public void setAppId(Integer appId)
    {
        this.appId = appId;
    }

    @JsonProperty("MessageTimeStamp")
	public String getMessageTimeStamp() {
		return messageTimeStamp;
	}

	public void setMessageTimeStamp(String messageTimeStamp) {
		this.messageTimeStamp = messageTimeStamp;
	}

}
