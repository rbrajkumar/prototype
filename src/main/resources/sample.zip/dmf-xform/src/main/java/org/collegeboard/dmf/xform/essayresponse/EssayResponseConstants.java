package org.collegeboard.dmf.xform.essayresponse;

public class EssayResponseConstants {
	public static final String MESSAGE_TOPIC_VERSION = "1.0.0";
	
	// bs assmnt 
	public static final String BS_ASSMNT_INFO_MEDIA_TYPE = "application/vnd.collegeboard.org.bsassessinfo-v1.0+json";
	public static final String BS_ASSMNT_REG_MEDIA_TYPE = "application/vnd.collegeboard.org.bsasmtreg-v1.0+json";
	public static final String DMF_CLOUD_SOA_PREFIX = "dmfcloud";
	
	// Element path and value
	public static final String AIRKEY_JPATH = "$.tdsreport.testee.airkey";
	public static final String TESTEE_ATTRIBUTE_JPATH = "$.tdsreport.testee.testeeattribute";
	public static final String REGISTRATION_NUM_JPATH = "$.tdsreport.testee.testeeattribute[?(@.name == 'ExternalID')]";
	public static final String EVENT_ID_JPATH = "$.tdsreport.testee.testeeattribute[?(@.name == 'EventID')]";
	public static final String FORM_ID_JPATH = "$.tdsreport.opportunity.segment.formID";
	public static final String ESSAY_CONTENT_JPATH = "$.tdsreport.opportunity.item.response[?(@.itemResponse)].itemResponse[?(@.response)]";
	
	//Assessment service 
	public static final String START_DATE_JPATH = "$.startDate";
	public static final String ASMT_RESP_ASMT_ID_JPATH = "$.AsmtRegistration[0].assessmentEvent.assessment.asmtId";
    public static final String ASMT_RESP_ASMT_SUB_TYP_CD_JPATH = "$.AsmtRegistration[0].assessmentEvent.assessment.asmtSubType.code";
    
    //Common
    public static final String VALUE = "value";
}
