package org.collegeboard.dmf.xform.essayresponse;

import static org.collegeboard.dmf.xform.essayresponse.EssayResponseConstants.AIRKEY_JPATH;
import static org.collegeboard.dmf.xform.essayresponse.EssayResponseConstants.BS_ASSMNT_INFO_MEDIA_TYPE;
import static org.collegeboard.dmf.xform.essayresponse.EssayResponseConstants.DMF_CLOUD_SOA_PREFIX;
import static org.collegeboard.dmf.xform.essayresponse.EssayResponseConstants.ESSAY_CONTENT_JPATH;
import static org.collegeboard.dmf.xform.essayresponse.EssayResponseConstants.EVENT_ID_JPATH;
import static org.collegeboard.dmf.xform.essayresponse.EssayResponseConstants.FORM_ID_JPATH;
import static org.collegeboard.dmf.xform.essayresponse.EssayResponseConstants.MESSAGE_TOPIC_VERSION;
import static org.collegeboard.dmf.xform.essayresponse.EssayResponseConstants.REGISTRATION_NUM_JPATH;
import static org.collegeboard.dmf.xform.essayresponse.EssayResponseConstants.START_DATE_JPATH;
import static org.collegeboard.dmf.xform.essayresponse.EssayResponseConstants.VALUE;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import org.collegeboard.dmf.common.utils.DMFHttpClient;
import org.collegeboard.dmf.common.utils.DMFHttpResponse;
import org.collegeboard.dmf.common.utils.DMFUtils;
import org.collegeboard.dmf.xform.XformRequest;
import org.collegeboard.dmf.xform.XformService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

public class EssayResponseXformService implements XformService {

	@Override
    public Object transform(XformRequest xformRequest, DocumentContext metadata, String jsonMessage)
    {
		DocumentContext input = null;
		Map<String, String> message = new LinkedHashMap<>();
		ObjectMapper mapper = new ObjectMapper();
		String out = null;
		try {
			input = JsonPath.parse(jsonMessage, DMFUtils.getJsonParserConfiguration());
			populate(message, input);
			out = mapper.writeValueAsString(message);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		return out;
	}

	private void populate(Map<String, String> message, DocumentContext input) throws Exception {
		message.put("MessageTopicVersionId", MESSAGE_TOPIC_VERSION);
		String airKey = input.read(AIRKEY_JPATH, String.class);
		message.put("MessageId", airKey+ "_" + format.format(new Date()));
		
		String registrationNum = "", eventID = "";
		List<Map<String, Object>> testeeattribute = input.read(REGISTRATION_NUM_JPATH);
		if(null != testeeattribute && !testeeattribute.isEmpty() && null != testeeattribute.get(0).get(VALUE))
        {
            registrationNum = testeeattribute.get(0).get(VALUE).toString();
        }
		
		message.put("RegistrationNum", registrationNum);
		
		testeeattribute = input.read(EVENT_ID_JPATH);
		if(null != testeeattribute && !testeeattribute.isEmpty() && null != testeeattribute.get(0).get(VALUE))
        {
            eventID = testeeattribute.get(0).get(VALUE).toString();
        }
		
		addBSAssmentData(message, eventID);
		message.put("EventId", eventID);
		message.put("AssessmentId", "1");  // Hard coded for essay
		
		String formId = input.read(FORM_ID_JPATH, String.class);
		message.put("EssayFormId", formId);
		message.put("DigitalUin", airKey);
		
		List<LinkedHashMap<String, ?>> items = input.read(ESSAY_CONTENT_JPATH);
		
		Boolean nullEssay = true;
		
		for(LinkedHashMap<String, ?> item : items) {
			if(null != item && item.containsKey("response")) {
				Map<?, ?> response = (Map<?, ?>)item.get("response");
				if(null != response.get(VALUE) && !isEmpty(response.get(VALUE).toString())) {
					nullEssay = false;
					String essayContent = response.get(VALUE).toString();
					essayContent = essayContent.replaceAll("\n", "").replaceAll("\t", "");
					message.put("EssayResponseData", essayContent);
					break;
				}
			}
		}
		
		if (nullEssay)
		{
			message.put("EssayResponseData", null);
		}
		
	}
	
	private void addBSAssmentData(Map<String, String> message, String eventID) throws InterruptedException, ExecutionException {
		if(isEmpty(eventID)) { // it is highly unlikely..since validation taken place much earlier.
			LOGGER.info("Invalid event ID, not able to process for assessments service call for adminDate");
			return;
		}
		
		LOGGER.info("starting task for AdminDate");
        String getEventURL = bsAssessInfoURL + "assessments/events/" + eventID;
        DMFHttpClient httpClient = new DMFHttpClient();
        DMFHttpResponse response = httpClient.doGet(getEventURL, bsAssessInfoURLMediaType, DMF_CLOUD_SOA_PREFIX);
        if(null == response || !DMFHttpClient.isSuccess(response.getStatusCode()))
        {
            throw new RuntimeException("Error in assessments service call : " + response.getResponseJson());
        }
        
        processAdminDate(response, message);
        LOGGER.info("end task for AdminDate");
	}

	private void processAdminDate(DMFHttpResponse dmfHttpResponse, Map<String, String> message) {
		Configuration configuration = DMFUtils.getJsonParserConfiguration();
        DocumentContext responseDocContext = JsonPath.parse(dmfHttpResponse.getResponseJson(), configuration);
        String startDate = responseDocContext.read(START_DATE_JPATH, String.class);
        if (DMFUtils.isEmptyString(startDate) || (startDate != null && startDate.length() != 10)) {
            throw new RuntimeException(String.format("Invalid startDate:%s", startDate));
        }
        
        message.put("AdminDate", startDate.replaceAll("-", ""));
	}
	
	private boolean isEmpty(String value) {
		return (null == value || value.length() < 1);
	}

	public EssayResponseXformService() {
		if (bsAssessInfoURL == null) {
            bsAssessInfoURL = System.getenv("BSASSESINFO_SERVICE_URL");
            bsAssessInfoURLMediaType = BS_ASSMNT_INFO_MEDIA_TYPE;
        }
	}
	
	private static String bsAssessInfoURL;
    private static String bsAssessInfoURLMediaType;
    
    private final static DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX") {
    	@Override
    	public void setTimeZone(java.util.TimeZone zone) {
    		zone.getTimeZone("UTC");
    	};
    };
    
    private static final Logger LOGGER = LoggerFactory.getLogger(EssayResponseXformService.class);
}
