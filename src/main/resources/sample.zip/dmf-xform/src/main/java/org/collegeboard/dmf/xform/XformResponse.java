package org.collegeboard.dmf.xform;

import org.collegeboard.dmf.common.api.DMFBaseServiceResponse;

public class XformResponse extends DMFBaseServiceResponse
{

}
