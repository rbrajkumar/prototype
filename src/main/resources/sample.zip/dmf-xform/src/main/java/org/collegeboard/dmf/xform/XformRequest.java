package org.collegeboard.dmf.xform;

import org.collegeboard.dmf.common.api.DMFBaseServiceRequest;

public class XformRequest extends DMFBaseServiceRequest
{

}
