package org.collegeboard.dmf.common.utils;

import java.util.Properties;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.S3Object;

public class DMFCredentialLoader
{

    private static Properties properties;


    private DMFCredentialLoader()
    {

    }

    public static String getUserName(String soaClientPrefix)
    {
        if (properties == null)
        {
            load();
        }
        return properties.getProperty(soaClientPrefix + DMFConstants.SOA_USER_NAME_KEY_SUFFIX);
    }

    public static String getPassword(String soaClientPrefix)
    {
        if (properties == null)
        {
            load();
        }
        return properties.getProperty(soaClientPrefix + DMFConstants.SOA_PASSWORD_KEY_SUFFIX);
    }

    private static synchronized void load()
    {
        AmazonS3 s3Client = AmazonS3ClientBuilder.standard().build();
        S3Object s3Object = null;
        try
        {
            String credentialsBucketName = System.getenv("CREDENTIALS_S3_BUCKET");
            String credentialsFileKey = System.getenv("CREDENTIALS_S3_KEY");
            s3Object = s3Client.getObject(credentialsBucketName, credentialsFileKey);
            properties = new Properties();
            properties.load(s3Object.getObjectContent());
        } catch (Exception ex)
        {
            throw new RuntimeException(ex);
        } finally
        {
            try
            {
                if (s3Object != null)
                {
                    s3Object.close();
                }
            } catch (Exception ex)
            {
                throw new RuntimeException(ex);
            }
        }
    }
}
