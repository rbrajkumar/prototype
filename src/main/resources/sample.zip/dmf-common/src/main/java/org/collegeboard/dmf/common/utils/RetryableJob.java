package org.collegeboard.dmf.common.utils;

public interface RetryableJob<T>
{
    public T job();

}
