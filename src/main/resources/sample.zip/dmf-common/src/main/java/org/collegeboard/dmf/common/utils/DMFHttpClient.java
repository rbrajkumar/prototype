package org.collegeboard.dmf.common.utils;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DMFHttpClient
{
    private static final Logger LOGGER = LoggerFactory.getLogger(DMFHttpClient.class);

    public static String HTTP_STATUS_SUCCESS = "SUCCESS";
    public static String HTTP_STATUS_ERROR = "ERROR";

    public DMFHttpResponse doGet(String requestURL, String accept, String soaClientPrefix)
    {
        DMFHttpRequest request = new DMFHttpRequest(soaClientPrefix);
        request.setRequestURL(requestURL);
        request.setAccept(accept);
        return doGet(request);
    }

    public DMFHttpResponse doGet(DMFHttpRequest request)
    {
        HttpURLConnection conn = null;
        DMFHttpResponse response;
        try
        {
            LOGGER.info("DMFHttpRequest:" + request.toString());
            URL url = new URL(request.getRequestURL());
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", request.getAccept());
            conn.setRequestProperty("Authorization", getAuthKey(request.getUserName(), request.getPassword()));

            int statusCode = conn.getResponseCode();
            if (isSuccess(statusCode))
            {
                response = new DMFHttpResponse(statusCode, getOutput(conn.getInputStream()));
            } else
            {
                response = new DMFHttpResponse(statusCode, getOutput(conn.getErrorStream()));
                LOGGER.info("DMFHttpResponse:" + response.toString());
            }
        } catch (Exception ex)
        {
            throw new RuntimeException(ex);
        } finally
        {
            if (conn != null)
            {
                conn.disconnect();
            }
        }
        return response;
    }

    private String getOutput(InputStream inputStream)
    {
        String output = "";
        BufferedReader br = null;
        try
        {
            br = new BufferedReader(new InputStreamReader(inputStream));

            String line = null;

            while ((line = br.readLine()) != null)
            {
                output = output + line;
            }

        } catch (Exception ex)
        {
            throw new RuntimeException(ex);
        } finally
        {
            if (br != null)
            {
                try
                {
                    br.close();
                } catch (Exception ex)
                {
                    LOGGER.error(ex.getMessage(), ex);
                }
            }
        }
        return output;
    }

    private String getAuthKey(String userName, String password)
    {

        String plainCreds = userName + ":" + password;

        String base64Creds = Base64.getEncoder().encodeToString(plainCreds.getBytes());

        return "Basic " + base64Creds;
    }

    public static boolean isSuccess(int statusCode)
    {
        if (statusCode >= 200 && statusCode <= 299)
        {
            return true;
        } else
        {
            return false;
        }
    }
}
