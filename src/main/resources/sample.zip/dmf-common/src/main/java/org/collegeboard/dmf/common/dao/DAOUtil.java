package org.collegeboard.dmf.common.dao;

import org.collegeboard.dmf.common.utils.DMFUtils;

import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.GetItemSpec;

public class DAOUtil
{
    public static Item getItemWithRetry(Table tbl, GetItemSpec getItemSpec)
    {
        return DMFUtils.execute(() -> {
            Item item = tbl.getItem(getItemSpec);
            if (item == null)
            {
                throw new RuntimeException("Item Not found");
            } else
            {
                return item;
            }
        });

    }
}
