package org.collegeboard.dmf.common.dao;

import java.util.Map;

import org.collegeboard.dmf.common.utils.DMFClientBuilder;

import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.GetItemSpec;

public class StageMessageInputDAO
{

    private static final String ID_COL = "messageIdentifier";
    private static final String JSON_MSG_COL = "jsonMessage";
    private static String stageMessageInputTBLName;
    private Table stageMessageInputTBL;
    private static String tableMsgTypeMetadata;
    private Table dynamoDBTableMsgTypeMetadata;
    
    public StageMessageInputDAO()
    {
        DynamoDB dynamoDB = DMFClientBuilder.getDaxClient();

        if (stageMessageInputTBLName == null)
        {
            stageMessageInputTBLName = System.getenv("DMF_MSG_INPUT_TABLE_NAME");
            tableMsgTypeMetadata = System.getenv("DMF_MSG_TYPE_TABLE_NAME");
        }
        stageMessageInputTBL = dynamoDB.getTable(stageMessageInputTBLName);
        dynamoDBTableMsgTypeMetadata = dynamoDB.getTable(tableMsgTypeMetadata);
    }

    public String getInputMessage(String messageIdentifier)
    {
        GetItemSpec getItemSpec = new GetItemSpec().withAttributesToGet(JSON_MSG_COL).withPrimaryKey(ID_COL,
                messageIdentifier);

        Item item = DAOUtil.getItemWithRetry(stageMessageInputTBL, getItemSpec);
        String inputMsg = null;
        if (item != null)
        {
            inputMsg = item.getString(JSON_MSG_COL);
        }
        return inputMsg;
    }
    
    public Map<String, Object> getMsgTypeDashboardMetadata(String messageTypeId)
    {
    	Item messageTypeMetadata = dynamoDBTableMsgTypeMetadata.getItem("messageTypeId", messageTypeId);
			
        return messageTypeMetadata.asMap();
    	
    }
}
