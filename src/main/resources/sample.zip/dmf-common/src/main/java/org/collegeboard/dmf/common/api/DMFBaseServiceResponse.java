package org.collegeboard.dmf.common.api;

public abstract class DMFBaseServiceResponse
{
    private String status;

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

}
