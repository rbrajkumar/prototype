package org.collegeboard.dmf.common.api;

public abstract class DMFBaseServiceRequest
{
    private String messageType;
    private String messageIdentifier;

    public String getMessageType()
    {
        return messageType;
    }

    public void setMessageType(String messageType)
    {
        this.messageType = messageType;
    }

    public String getMessageIdentifier()
    {
        return messageIdentifier;
    }

    public void setMessageIdentifier(String messageIdentifier)
    {
        this.messageIdentifier = messageIdentifier;
    }

}
