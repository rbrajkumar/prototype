package org.collegeboard.dmf.common.utils;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.collegeboard.dmf.common.api.DMFBaseServiceRequest;
import org.collegeboard.dmf.common.dao.StageMessageInputDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

public class DMFKinesisLogger
{
    private static final Logger LOGGER = LoggerFactory.getLogger(DMFKinesisLogger.class);

    private static final String KINESIS_CB_MON_IDX = "dmfessayscore";
    private StageMessageInputDAO stageMessageInputDAO;
    private Configuration jsonConfiguration;

    public DMFKinesisLogger()
    {
        stageMessageInputDAO = new StageMessageInputDAO();
        jsonConfiguration = DMFUtils.getJsonParserConfiguration();
    }

    public DocumentContext createMessageJson(String messageTypeId, String messageIdentifier, String inputMessage,
            String env, String serviceName) throws JsonProcessingException, IOException
    {
        DocumentContext kinesisMsgJson = JsonPath.parse("{}");
        kinesisMsgJson.put("$", "appName", DMFConstants.DMF_APP_NAME);
        kinesisMsgJson.put("$", "environment", env);
        kinesisMsgJson.put("$", "serviceName", serviceName);
        kinesisMsgJson.put("$", "cbMonIdx", KINESIS_CB_MON_IDX);
        kinesisMsgJson.put("$", "messageIdentifier", messageIdentifier);

        if (inputMessage != null && messageTypeId != null)
        {
            appendDashboardAttributes(messageTypeId, inputMessage, kinesisMsgJson);
        }
        return kinesisMsgJson;
    }

    private void appendDashboardAttributes(String messageTypeId, String inputMessage, DocumentContext kinesisMsgJson)
    {
        try
        {
            Map<String, Object> metadataMap = stageMessageInputDAO.getMsgTypeDashboardMetadata(messageTypeId);
            kinesisMsgJson.put("$", "messageType", metadataMap.get("messageTypeCd"));

            List<LinkedHashMap<String, Object>> list = JsonPath.read(metadataMap.get("dashboardMetadata"),
                    "$.attributes");

            DocumentContext inputJsonDoc = JsonPath.parse(inputMessage, jsonConfiguration);
            String attributeName = null;
            List<?> jsonPathList = null;
            for (LinkedHashMap<String, Object> attributes : list)
            {
                attributeName = (String) attributes.get("name");
                jsonPathList = (List<?>) attributes.get("jsonPath");
                appendDashboardAttribute(inputJsonDoc, kinesisMsgJson, attributeName, jsonPathList);
            }
        } catch (Exception ex)
        {
            LOGGER.error(ex.getMessage(), ex);
        }
    }

    private void appendDashboardAttribute(DocumentContext inputJsonDoc, DocumentContext kinesisMsgJson,
            String attributeName, List<?> jsonPathList)
    {
        String value = "";
        Object valObj = null;

        for (Object jsonPathObj : jsonPathList)
        {
            valObj = inputJsonDoc.read(jsonPathObj.toString());
            if (valObj != null)
            {
                value = value + valObj.toString();
            }
        }
        kinesisMsgJson.put("$", attributeName, value);
    }

    public static String getMessage(String requestId, String kinesisMsgJsonStr)
    {
        return requestId + " toSoaMonitoring format:json " + kinesisMsgJsonStr;

    }

    public DocumentContext logServiceStart(DMFBaseServiceRequest serviceRequest, String env, String serviceName)
            throws JsonProcessingException, IOException
    {
        String inputMessage = null;
        try
        {
            inputMessage = stageMessageInputDAO.getInputMessage(serviceRequest.getMessageIdentifier());
        } catch (Exception ex)
        {
            LOGGER.error("Unable to get input message", ex);
        }

        DocumentContext kinesisMsgJson = createMessageJson(serviceRequest.getMessageType(), serviceRequest
                .getMessageIdentifier(), inputMessage, env, serviceName);

        logServiceStatus(kinesisMsgJson, DMFConstants.SERVICE_STATUS_STARTED, null);
        return kinesisMsgJson;
    }

    public DocumentContext logServiceStatus(DocumentContext kinesisMsgJson, String serviceStatus, String response)
    {
        try
        {
            updateStatus(kinesisMsgJson, serviceStatus, response);
            LOGGER.info(getMessage(kinesisMsgJson.read("$.messageIdentifier"), kinesisMsgJson.jsonString()));

        } catch (Exception ex)
        {
            String kinesisMsgJsonStr = null;
            if (kinesisMsgJson != null)
            {
                kinesisMsgJsonStr = kinesisMsgJson.jsonString();
            }
            LOGGER.error(String.format("Error in logging kinesis message.kinesisMsgJson:%s, response:%s",
                    kinesisMsgJsonStr, response), ex);
        }
        return kinesisMsgJson;
    }

    public DocumentContext logServiceSuccess(DocumentContext kinesisMsgJson, String response)
    {
        logServiceStatus(kinesisMsgJson, DMFConstants.SERVICE_STATUS_SUCCESS, response);
        return kinesisMsgJson;
    }

    public DocumentContext logServiceError(DocumentContext kinesisMsgJson, Throwable throwable)
    {
        logServiceStatus(kinesisMsgJson, DMFConstants.SERVICE_STATUS_ERROR, throwable.getMessage());
        LOGGER.error(throwable.getMessage(), throwable);
        return kinesisMsgJson;
    }

    public void updateStatus(DocumentContext kinesisMsgJson, String status, String response)
    {
        kinesisMsgJson.put("$", "status", status);
        kinesisMsgJson.put("$", "response", response);
        kinesisMsgJson.put("$", "@timestamp", DMFUtils.getCurrentTime());
    }

}
