package org.collegeboard.dmf.common.utils;

public class DMFHttpRequest
{
    private String requestURL;
    private String accept;
    private String contentType;
    private String userName;
    private String password;
    private String requestJson;

    public DMFHttpRequest()
    {

    }

    public DMFHttpRequest(String soaClientPrefix)
    {
        setUserName(DMFCredentialLoader.getUserName(soaClientPrefix));
        setPassword(DMFCredentialLoader.getPassword(soaClientPrefix));
    }

    public String getRequestURL()
    {
        return requestURL;
    }

    public void setRequestURL(String requestURL)
    {
        this.requestURL = requestURL;
    }

    public String getAccept()
    {
        return accept;
    }

    public void setAccept(String accept)
    {
        this.accept = accept;
    }

    public String getContentType()
    {
        return contentType;
    }

    public void setContentType(String contentType)
    {
        this.contentType = contentType;
    }

    public String getUserName()
    {
        return userName;
    }

    public void setUserName(String userName)
    {
        this.userName = userName;
    }

    public String getPassword()
    {
        return password;
    }

    public void setPassword(String password)
    {
        this.password = password;
    }

    public String getRequestJson()
    {
        return requestJson;
    }

    public void setRequestJson(String requestJson)
    {
        this.requestJson = requestJson;
    }

    public String toString()
    {
        StringBuilder strBuilder = new StringBuilder();
        strBuilder.append(String.format("requestURL:%s ", this.requestURL));
        strBuilder.append(String.format("accept:%s ", this.accept));
        strBuilder.append(String.format("contentType:%s ", this.contentType));
        strBuilder.append(String.format("requestJson:%s ", this.requestJson));
        return strBuilder.toString();
    }

}
