package org.collegeboard.dmf.common.utils;

public class DMFHttpResponse
{
    private int statusCode;
    private String responseJson;

    public DMFHttpResponse()
    {

    }

    public DMFHttpResponse(int statusCode, String responseJson)
    {
        this.statusCode = statusCode;
        this.responseJson = responseJson;
    }

    public int getStatusCode()
    {
        return statusCode;
    }

    public void setStatusCode(int statusCode)
    {
        this.statusCode = statusCode;
    }

    public String getResponseJson()
    {
        return responseJson;
    }

    public void setResponseJson(String responseJson)
    {
        this.responseJson = responseJson;
    }

    public String toString()
    {
        StringBuilder strBuilder = new StringBuilder();
        strBuilder.append(String.format("statusCode:%s ", this.statusCode));
        strBuilder.append(String.format("responseJson:%s ", this.responseJson));
        return strBuilder.toString();
    }

}
