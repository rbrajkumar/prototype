package org.collegeboard.dmf.common.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazon.dax.client.dynamodbv2.AmazonDaxClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;

public class DMFClientBuilder
{

    private static final Logger LOGGER = LoggerFactory.getLogger(DMFClientBuilder.class);

    private static DynamoDB DAX_CLIENT;

    private static DynamoDB DYNAMO_CLIENT;

    private DMFClientBuilder()
    {

    }

    public static synchronized DynamoDB getDynamoDBClient()
    {
        if (DYNAMO_CLIENT == null)
        {
            AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().build();
            DYNAMO_CLIENT = new DynamoDB(client);
        }
        return DYNAMO_CLIENT;
    }

    public static synchronized DynamoDB getDaxClient()
    {
        if (DAX_CLIENT == null)
        {
            DAX_CLIENT = createDaxClientWithRetry();
        }

        return DAX_CLIENT;
    }

    private static DynamoDB createDaxClientWithRetry()
    {
        String env = System.getenv("ENVIRONMENT");
        String daxEndpoint = DMFUtils.getParameterValue(env + DMFConstants.DAX_CLUSTER_ENDPOINT_PARAM_KEY);

        return DMFUtils.execute(() -> {
            DynamoDB dynamoDB = createDaxClient(daxEndpoint);
            if (dynamoDB == null)
            {
                throw new RuntimeException("Error in DAX Client creation");
            } else
            {
                return dynamoDB;
            }
        });

    }

    private static DynamoDB createDaxClient(String daxEndpoint)
    {
        try
        {
            AmazonDaxClientBuilder daxClientBuilder = AmazonDaxClientBuilder.standard();
            daxClientBuilder.withEndpointConfiguration(daxEndpoint);
            AmazonDynamoDB client = daxClientBuilder.build();
            return new DynamoDB(client);
        } catch (Exception ex)
        {
            LOGGER.error(ex.getMessage(), ex);
            return null;
        }
    }
}
