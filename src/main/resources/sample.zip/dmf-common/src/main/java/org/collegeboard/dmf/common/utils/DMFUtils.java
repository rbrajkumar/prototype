package org.collegeboard.dmf.common.utils;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.simplesystemsmanagement.AWSSimpleSystemsManagement;
import com.amazonaws.services.simplesystemsmanagement.AWSSimpleSystemsManagementClientBuilder;
import com.amazonaws.services.simplesystemsmanagement.model.GetParameterRequest;
import com.amazonaws.services.simplesystemsmanagement.model.GetParameterResult;
import com.amazonaws.services.simplesystemsmanagement.model.ParameterNotFoundException;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.Option;
import com.jayway.jsonpath.spi.json.JacksonJsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;

public class DMFUtils
{
    private static final Logger LOGGER = LoggerFactory.getLogger(DMFUtils.class);

    public static String getCurrentTime()
    {
        return Instant.now().toString();
    }

    public static Map<String, String> getCredentials(String bucketName, String fileName, String clientPrefix)
    {
        AmazonS3 s3Client = AmazonS3ClientBuilder.standard().build();
        S3Object s3Object = null;
        Map<String, String> credentialsMap = new HashMap<>();
        try
        {
            s3Object = s3Client.getObject(bucketName, fileName);
            Properties properties = new Properties();
            properties.load(s3Object.getObjectContent());
            credentialsMap.put("username", properties.getProperty(clientPrefix + ".username"));
            credentialsMap.put("password", properties.getProperty(clientPrefix + ".password"));
            
        } catch (AmazonServiceException ase)
        {
            LOGGER.error(ase.getMessage(), ase);
            String message = String.format(
                    "S3 rejected:Error Message:%s,HTTP Status Code:%s,AWS Error Code:%s,Error Type:%s,Request ID:%s",
                    ase.getMessage(), ase.getStatusCode(), ase.getErrorCode(), ase.getErrorType(), ase.getRequestId());

            throw new RuntimeException(message, ase);
        } catch (AmazonClientException ace)
        {
            LOGGER.error(ace.getMessage(), ace);
            throw new RuntimeException(ace);

        } catch (Exception ex)
        {
            LOGGER.error(ex.getMessage(), ex);
            throw new RuntimeException(ex);

        } finally
        {
            try
            {
                if (s3Object != null)
                {
                    s3Object.close();
                }
            } catch (Exception ex)
            {
                throw new RuntimeException(ex);
            }
        }
        return credentialsMap;
    }
    

    public static String getStackTrace(final Throwable throwable)
    {
        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw, true);
        throwable.printStackTrace(pw);
        return sw.getBuffer().toString();
    }

    public static boolean isEmptyString(String str)
    {
        return str == null || str.length() == 0;
    }

    public static String getParameterValue(String parameterName)
    {
        try
        {
            AWSSimpleSystemsManagement ssmClient = AWSSimpleSystemsManagementClientBuilder.defaultClient();
            GetParameterRequest getParameterRequest = new GetParameterRequest();
            getParameterRequest.withName(parameterName);
            GetParameterResult getParameterResult = ssmClient.getParameter(getParameterRequest);
            return getParameterResult.getParameter().getValue();
        } catch (ParameterNotFoundException ex)
        {
            LOGGER.error("Parameter NotFound with name: " + parameterName);
            return null;
        }
    }

    public static String formatDate(String dateStr, String inputDtFormat, String outputDtFormat)
    {
        try
        {
            SimpleDateFormat inputTsFormat = new SimpleDateFormat(inputDtFormat);
            SimpleDateFormat outputTsFormat = new SimpleDateFormat(outputDtFormat);
            Date sourceDate = inputTsFormat.parse(dateStr);
            return outputTsFormat.format(sourceDate);
        } catch (Exception ex)
        {
            throw new RuntimeException(String.format(
                    "Error in date Conversion. Source date:%s,inputDtFormat:%s,outputDtFormat:%s", dateStr,
                    inputDtFormat, outputDtFormat), ex);
        }
    }

    public static Configuration getJsonParserConfiguration()
    {
        return Configuration.defaultConfiguration()
                .addOptions(Option.DEFAULT_PATH_LEAF_TO_NULL, Option.SUPPRESS_EXCEPTIONS)
                .jsonProvider(new JacksonJsonProvider())
                .mappingProvider(new JacksonMappingProvider());
    }

    public static <T> T execute(RetryableJob<T> retryableJob)
    {
        int maxTries = 3;
        int currentTry = 0;
        int waitTime = 1000;

        boolean isRetry = true;
        while (isRetry)
        {
            currentTry++;
            try
            {
                return retryableJob.job();
            } catch (Exception ex)
            {
                if (currentTry > maxTries)
                {
                    isRetry = false;
                    throw ex;
                } else
                {
                    LOGGER.warn(ex.getMessage(), ex);
                    LOGGER.info(String.format("Waiting for %s Milliseconds before retry", waitTime));
                    try
                    {
                        Thread.sleep(waitTime);
                    } catch (InterruptedException e)
                    {
                        LOGGER.error(ex.getMessage(), e);
                    }
                }
            }
        }
        return null;

    }


}
