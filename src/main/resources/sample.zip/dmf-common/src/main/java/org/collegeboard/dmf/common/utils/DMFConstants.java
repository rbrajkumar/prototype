package org.collegeboard.dmf.common.utils;

public class DMFConstants
{
    public static final int DMF_APP_ID = 303;
    public static final String DMF_APP_NAME = "dmf";

    public static final String SERVICE_STATUS_STARTED = "STARTED";
    public static final String SERVICE_STATUS_SUCCESS = "SUCCESS";
    public static final String SERVICE_STATUS_ERROR = "ERROR";
    public static final String SERVICE_STATUS_WARNING = "WARNING";

    public static final String LAMBDA_TAG_ENVIRONMENT = "environment";
    public static final String LAMBDA_TAG_APP_NAME = "cb_program";
    public static final String LAMBDA_TAG_SERVICE_NAME = "service_name";

    public static final String DMF_CLOUD_SOA_PREFIX = "dmfcloud";
    public static final String SOA_USER_NAME_KEY_SUFFIX = ".username";
    public static final String SOA_PASSWORD_KEY_SUFFIX = ".password";

    public static final String BSITEMRESP_SERVICE_MEDIA_PRIMARY_TYPE = "application";
    public static final String BSITEMRESP_SERVICE_MEDIA_SUB_TYPE = "vnd.collegeboard.org.bsItemResp-v1.0+xml";

    public static final String DAX_CLUSTER_ENDPOINT_PARAM_KEY = "_DAX_CLUSTER_ENDPOINT";

    public static final int RETRY_THRESHOLD = 3;

}
